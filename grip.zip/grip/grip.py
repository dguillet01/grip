from modules.debugging        import *
from modules.HPeSSE           import *

DEBUG = True

debugger = Debugging("apiRequest",debug_activation=DEBUG,debug_type=DEBUG_TARGET.TO_SCREEN)

token = "put your token here "
sse = HPeSSE(token)

sse.loadConnectorZonesList()
sse.loadConnectorList()
sse.loadTagsList()
sse.loadApplicationList()


ip_ranges = ("10.10.1.0/24","10.10.2.0/24","10.10.3.0/24","10.10.4.0/24")
tags = ("Dad","InternalAdmin")
ports_and_protocols =("1000-3000","22:tcp","53:udp")
sse.createNewNetworkRangeApplication("toto 0","Online_scaleway",ip_ranges_or_cidrs=ip_ranges,tags=tags,ports_and_protocols=ports_and_protocols)

sse.commitChanges()

debugger.logThis("Here is the list of connector zones ", sse.getConnectorZoneList())

