from modules.debugging        import *
from modules.HPeSSE           import *

DEBUG = True

debugger = Debugging("apiRequest",debug_activation=DEBUG,debug_type=DEBUG_TARGET.TO_SCREEN)

token = "put your token here "
sse = HPeSSE(token)

sse = HPeSSE(token)
sse.toggleDebug()
sse.logThis("coucou")
sse.loadConnectorZonesList()
sse.loadConnectorList()
sse.loadTagsList()
sse.loadApplicationList()
sse.loadWebCategoriesList()

name = "Grip Allow"
urls = ["*.grip.com","hpe.com"]
exclude_urls = ["www.grip.com/hpe","hpe.com/juniper"]

# Example on how to Create a Web Category 
sse.createNewWebCategory(name, excluded_urls=exclude_urls)

# Example on how to modify a Web Category and add URLs/Domains in the allow list 
urls = ["*.google.com","microsoft.com"]
sse.addUrlOrDomainsToWebCategory(name,included_urls=urls)

# Example on how to modify a Web Category and add URLs/Domains in the deny list 
exclude_urls = ["www.google.com/gmail","microsoft.com/entra"]
sse.addUrlOrDomainsToWebCategory(name,excluded_urls=exclude_urls)

# Example on how to modify a Web Category and add URLs/Domains in the allow list and in the deny list at the same time
urls = ["*.openai.com","meta.com"]
exclude_urls = ["www.openai.com/gpt5","meta.com/facebook"]
sse.addUrlOrDomainsToWebCategory(name,included_urls=urls,excluded_urls=exclude_urls)

# Don't forget to always commit the changes
sse.commitChanges()
