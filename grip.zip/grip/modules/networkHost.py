"""
NetworkHost: A Simple Library for Network hosts
Author: David Guillet
Creation Date: Nov. 20 2023
Last Modified Date: Jan. 29 2025
Version: 1.0.8
Version History :
    1.0.0 : Initial release (Copy from previous projects)
    1.0.1 : Adding a isReachable method 
    1.0.2 : Adding a network unreachable check 
    1.0.3 : Adding ssh execution methods and properties 
    1.0.4 : Adding paramiko usage for ssh access methods
    1.0.5 : Adding a test for ssh connection only if username and password are defined
    1.0.6 : Adding methods to upload a file, copy a file and to create a directory
    1.0.7 : Adding methods to handle websocket connections
    1.0.8 : Adding Interactive shell mode to handle device specific ssh access
"""

from modules.debugging import *
import subprocess
import sys
import socket
import paramiko
import asyncio
import websockets
import time

DEFAULT_TCP_PORT_FOR_CONNECTIVITY_TEST = 443
"""
Defined in : \n
\nnetworkHost.py \n
Description : \n
\tThis the default value for the TCP port used for the host connectiviy test.\n
\tBy default it is set to 443 (HTTPS).\n 
\tIf you want to change it globally then edit the nnetworkHost.py file and set it to the desired value and don't forget to change this message"""


DEFAULT_SSH_PORT = 22
"""
Defined in : \n
\nnetworkHost.py \n
Description : \n
\tThis the default value for the TCP port used for the ssh host access.\n
\tBy default it is set to 22.\n 
\tIf you want to change it globally then edit the nnetworkHost.py file and set it to the desired value and don't forget to change this message"""

_LOGFILE_PREFIX = "NetworkHost_"

class NetworkHost(Debugging):

    def __init__(self, fqdn, username = IGNORE_THIS, password = IGNORE_THIS, tcp_port_to_test = DEFAULT_TCP_PORT_FOR_CONNECTIVITY_TEST, ssh_port = DEFAULT_SSH_PORT, interactive_mode = False,log_file_name = IGNORE_THIS, path_for_log_file= DEFAULT_PATH_FOR_LOGFILE,debug_activation=DEFAULT_DEBUGGING_STATE, debug_type=DEFAULT_DEBUGGING_TYPE):
        """
        Initialize the networkHost object with the given parameters. 
        Parameters:
        - fqdn              (str) : The name or IP address of the server to connect to. This is a mandatory parameter
        - username          (str) : The username to use to connect to the host.  Defaults to IGNORE_THIS.
        - password          (str) : Username's password to use to connect to the host.  Defaults to IGNORE_THIS.
        - tcp_port_to_test  (int) : TCP port used to test connectivity to the host. Defaults to 443
        - ssh_port          (int) : TCP port used to ssh to the host. Defaults to 22
        - interactive_mode  (bool): sets the shell to interactive mode,
        - log_file_name     (str) : The log file name. Defaults to IGNORE.
        - path_for_log_file (str) : The path for the log file. Defaults to DEFAULT_PATH_FOR_LOGFILE.
        - debug_activation  (bool): The activation state of debugging. Defaults to DEFAULT_DEBUGGING_STATE.
        - debug_type        (int) : The type of debugging. Defaults to DEFAULT_DEBUGGING_TYPE.
        """
        if (log_file_name == IGNORE_THIS):
            super().__init__(_LOGFILE_PREFIX + str(fqdn), path_for_log_file, debug_activation, debug_type)
        else:
            super().__init__(log_file_name, path_for_log_file, debug_activation, debug_type)
        self.beginMethodSeparator("Network Host Object creation")
        self.__fqdn                         = fqdn
        self.__ipAddress                    = IGNORE_THIS
        self.__username                     = username
        self.__password                     = password
        self.__tcp_port_to_test             = tcp_port_to_test
        self.__ssh_port                     = ssh_port
        self.__interactive_mode             = interactive_mode
        self.__interactive_shell            = None
        self.__connected                    = False
        self.__connection_error             = False
        self.__validity                     = False
        self.__reachable                    = False
        self.__ssh_command_result_available = False
        self.__ssh_command_result_error     = False
        self.__ssh_command_result           = None
        self.__ssh_connection               = None
        self.websocket_uri                  = None
        self.websocket_message_handler      = None
        self.websocket_id                   = None
        self.websocket_listener_task        = None
        
        self.__checkValidity()
        self.__checkConnectivity()
        if (self.__username != IGNORE_THIS and self.__password != IGNORE_THIS):
            self.__openSSHConnection()

    def __checkValidity(self):
        self.beginMethodSeparator("Check validity",1)
        try:
            self.__ipAddress = socket.gethostbyname(self.__fqdn)  
            self.logThis(f"IP address resolved for [{self.__fqdn}]", self.__ipAddress,2)
            self.__validity = True
        except socket.gaierror as error_description:
            self.logThis("Error resolving hostname IP Address for ",self.__fqdn,2)
        finally:
            self.endMethodSeparator(1)
    
    def __checkConnectivity(self,tcp_port_to_test = IGNORE_THIS, indent_value = 1):
        """
        Check the connectity to the networkHost using the TCP port specified in the parameters. 
        Parameters:
        - tcp_port_to_test  (int) : The TCP port to connect if not specified then the default or existing one will be used. 
        """
        self.beginMethodSeparator("Check reachability",indent_value)
        if (self.__validity):
            if (tcp_port_to_test != IGNORE_THIS):
                self.logThis("Changing TCP port to ", tcp_port_to_test, indent_value + 1)
                self.__tcp_port_to_test = tcp_port_to_test
            try:
                self.logThis("Trying to open TCP socket on port ", self.__tcp_port_to_test, indent_value + 1)
                testSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                testSocket.settimeout(5)
                testSocket.connect((self.__fqdn, self.__tcp_port_to_test))
                testSocket.shutdown(socket.SHUT_RDWR)
                self.__reachable = True
                self.logThis("Succeed! Network host reachable on port ", self.__tcp_port_to_test, indent_value + 2)
            except (socket.timeout, ConnectionRefusedError):
                self.logThis("Failed! Network host NOT reachable on port ", self.__tcp_port_to_test, indent_value + 2)
                self.__reachable = False
            except Exception as errorDescription:
                self.logThis(f"Failed with error {errorDescription} ", indent_value + 2)
                self.__reachable = False
            finally:
                self.endMethodSeparator(indent_value)

        else:
            self.logThis("Invalid hostname", self.__fqdn, indent_value + 1)
            self.__reachable = False
            self.endMethodSeparator(indent_value)

    def __openSSHConnection(self, indent_value = 1):
        """
        Open a SSH connection to execute commands towards the network host
        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.
        Returns:
            Return the true if the connection was establish otherwise it returns false.
        """
        self.beginMethodSeparator("openSSHConnection",indent_value)
        indent_value += 1
        result = False

        if self.__reachable:
            try:
                self.logThis("Creating Client connection for user",self.__username, tabs=indent_value)
                self.__ssh_connection = paramiko.client.SSHClient()
                self.__ssh_connection.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                self.logThis("Connecting ...", tabs=indent_value)
                self.__ssh_connection.connect(self.__fqdn,port = self.__ssh_port, username=self.__username, password=self.__password,look_for_keys=False,allow_agent=False)
                self.logThis("Connected successfuly !", tabs=indent_value + 1)
                if self.__interactive_mode:
                    self.__interactive_shell = self.__ssh_connection.invoke_shell()
                    time.sleep(0.1)
                    self.logThis("Interactive shell created successfuly !", tabs=indent_value + 2)
                





                self.__connected = True
                
            except paramiko.AuthenticationException:
                self.__connected = False
                self.__connection_error = "Authentication failed"
                self.logThis("Connection failed ", self.__connection_error,indent_value + 1)
            except paramiko.SSHException as sshException:
                self.__connected = False
                self.__connection_error = f"Unable to establish SSH connection: {sshException}"
                self.logThis("Connection failed ", self.__connection_error,indent_value + 1)
            except Exception as e:
                self.__connected = False
                self.__connection_error = f"Exception in connecting to the server: {e}"
                self.logThis("Connection failed ", self.__connection_error,indent_value + 1)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def isReachable(self, indent_value = 1):
        """
        Returns the reachability status of the host. True if the host is reachable and False otherwise
        """

        return self.__reachable
    
    def isConnected(self, indent_value = 1):
        """
        Returns the connection status of the host. True if there is a connection opened to the hostand False otherwise
        """

        return self.__connected
    
    

    def changeFQDN(self, new_fqdn, new_tcp_port_to_test = DEFAULT_TCP_PORT_FOR_CONNECTIVITY_TEST, indent_value = 1):
        """
        Change the FQDN of the instance and launch again to validity and connectivity check.
        Args:
            new_fqdn (str): The name or IP address of the server to connect to. This is a mandatory parameter
            new_tcp_port_to_test (int, optional): TCP port used to connect to the host. Defaults to 443
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.
        """
        self.beginMethodSeparator("changeFQDN",indent_value)
        indent_value += 1
        result = False

        self.__fqdn = new_fqdn
        self.__tcp_port_to_test          = new_tcp_port_to_test
        self.__connected                 = False
        self.__validity                  = False
        self.__reachable                 = False
        self._checkValidity()
        self.checkConnectivity()



        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def executeSSHCommandOld(self, command, indent_value = 1):
        """Execute an SSH command returns true if the command succeeded

        Args:
            command (str): Command to execute.
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.
        """
        self.beginMethodSeparator("executeSSHCommand",indent_value)
        indent_value += 1
        result = False


        self.logThis("Executing command ", "%s" % command, indent_value + 1)
        self.logThis("Preparing connection string ",tabs= indent_value)
        self.logThis("SSH Host ", self.__fqdn, indent_value + 1)
        self.logThis("SSH Port ", self.__tcp_port_to_test, indent_value + 1)
        self.logThis("User     ", self.__username, indent_value + 1)
        connection_string = self.__username + ":" + self.__password + '@' + self.__fqdn
        connection_port = "-p " + str(self.__tcp_port_to_test)
        self.logThis("Executing command ", command, indent_value)
        ssh_execution_process = subprocess.Popen(["ssh",connection_string, connection_port, command],shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE)

        self.__ssh_command_result = ssh_execution_process.stdout.readlines()
        if self.__ssh_command_result == []:
            self.logThis("Command failed",tabs= indent_value)
            self.__ssh_command_result_error = ssh_execution_process.stderr.readlines()
            self.logThis("Error details ", self.__ssh_command_result_error, indent_value + 1)
        else:
            self.logThis("Command succeed",tabs= indent_value)
            self.logThis("Result details ", self.__ssh_command_result, indent_value + 1)
            self.__ssh_command_result_available = True
            result = True


        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result


    def __readAllSSHOutput(self, prompt="#", timeout=5):
        result = ""
        start_time = time.time()
    
        while True:
            if self.__interactive_shell.recv_ready():
                result += self.__interactive_shell.recv(4096).decode()
                
            # Check if we reached the expected prompt
            if result.strip().endswith(prompt):
                break
            
            # Timeout to prevent infinite loops
            if time.time() - start_time > timeout:
                break

            time.sleep(0.1)  # Small delay to avoid 100% CPU usage
        
        return result

    def executeSSHCommand(self, command, indent_value = 1):
        """Execute an SSH command returns true if the command succeeded

        Args:
            command (str): Command to execute.
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.
        """
        self.beginMethodSeparator("executeSSHCommand",indent_value)
        indent_value += 1
        result = False
        self.__ssh_command_result_available = False

        if self.__connected:
            try:
                self.logThis("Executing command ", command, indent_value)
                if self.__interactive_mode:
                    self.logThis("Using interactive shell",tabs= indent_value + 1)
                    if self.__interactive_shell.recv_ready():
                        self.__interactive_shell.recv(1024)
                    if command[-1] != "\n":
                        command += "\n"
                    self.__interactive_shell.send(command)
                    time.sleep(2)  # Wait for output
                    self.__ssh_command_result = self.__readAllSSHOutput()
                    result = True                
                    self.__ssh_command_result_available = True

                else:
                    self.logThis("Using direct connection",tabs= indent_value + 1)
                    stdin, stdout, stderr = self.__ssh_connection.exec_command(command)
                    self.logThis("Command executed ",tabs= indent_value + 2)
                    # input  = stdin.read().decode('utf-8')
                    output = stdout.read().decode('utf-8').strip()
                    error  = stderr.read().decode('utf-8').strip()
                    if error:
                        self.logThis("Command returned an error",tabs= indent_value + 2)
                        self.__ssh_command_result_error = f"Error: {error}"
                        self.logThis("Error details ", self.__ssh_command_result_error, indent_value + 2)
                    else:
                        self.__ssh_command_result = output
                        self.logThis("Command succeed",tabs= indent_value + 2)
                        self.logThis("Result details ", self.__ssh_command_result, indent_value + 2)
                        result = True                
                        self.__ssh_command_result_available = True

            except Exception as e:
                print(e)
                self.logThis("Command failed",tabs= indent_value)
                self.__ssh_command_result_error = f"{e}"
                self.logThis("Error details ", self.__ssh_command_result_error, indent_value + 1)
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return result

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def readSSHCommandResult(self, indent_value = 1):
        """Reads the result of an SSH command 
        
        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.
        """
        result = False

        if self.__ssh_command_result_available:
            result = self.__ssh_command_result

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def checkIfRemoteFileExists(self,remote_file_name, indent_value = 1):
        """
          Check if a remote file exists on the network host 
           
        Args:

        Returns:
            Return True if the file exists otherwise it returns false.
        """

        result = False

        self.beginMethodSeparator("Check file exists",indent_value)
        indent_value += 1

        if self.__connected:
            self.logThis(f"Checking if file {remote_file_name} exists", tabs = indent_value)
            try:
                self.logThis("Opening connection ...", tabs = indent_value + 1)
                sftp_connection = self.__ssh_connection.open_sftp()
                self.logThis("Checking file ...", tabs = indent_value + 1)
                sftp_connection.stat(remote_file_name)
                result = True
                sftp_connection.close()
            except FileNotFoundError:
                # File does not exist
                self.logThis("Remote file does not exist.", tabs = indent_value + 1)
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return False

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def uploadFile(self,source_filename, remote_path, source_path = IGNORE_THIS, remote_filename = IGNORE_THIS,force_upload = False, indent_value = 1):
        """
          Upload a local file to to the network host 
           
        Args:
            source_filename (str): the name of the source file
            remote_path (str): the destination path where the file should be copied
            source_path (str, optional): the source path where the source file should be read, if not specified it will be read from current directory
            remote_filename (str, optional): the name of the file on the network host, if not specified the same name than the source filename will be used.
            force_upload (boolean,optional): optional value if set to True then the method will not check if the file already exists and overwrite the file on the network host
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to upload the file otherwise it returns false.
        """

        # Add here the possibility to upload the file only if it is not already in there and if it is the first time upload

        result = False

        self.beginMethodSeparator("Upload a file",indent_value)
        indent_value += 1

        local_file  = source_filename
        remote_file = source_filename
        if source_path != IGNORE_THIS:
            local_file = source_path + "/" + local_file
        if remote_filename != IGNORE_THIS:
            remote_file = remote_filename
        remote_file = remote_path + "/" + remote_file

        if not self.checkIfRemoteFileExists(remote_file):
            self.logThis("File Doesn't exists activatig the force upload", tabs = indent_value)
            force_upload = True

        if force_upload:
            if self.__connected:
                self.logThis(f"Copying {local_file} to {remote_file}", tabs = indent_value)
                try:
                    self.logThis("Opening connection ...", tabs = indent_value)
                    sftp_connection = self.__ssh_connection.open_sftp()
                    self.logThis("Uploading file ...", tabs = indent_value)
                    sftp_connection.put(local_file, remote_file)
                except FileNotFoundError as e:
                    self.logThis("Local file not found", tabs = indent_value + 1)
                    indent_value -= 1
                    self.endMethodSeparator(indent_value)
                    return result
                except IOError as e:
                    self.logThis(f"File upload failed : {e}", tabs = indent_value + 1)
                    indent_value -= 1
                    self.endMethodSeparator(indent_value)
                    return result
                except Exception as e:
                    self.logThis(f"Unhandled error occured : {e}", tabs = indent_value + 1)
                    indent_value -= 1
                    self.endMethodSeparator(indent_value)
                    return result
                finally:
                    self.logThis("Closing connection ...", tabs = indent_value)
                    sftp_connection.close()
                    result = True
        else:
            self.logThis("Remote file already exists and force uplood is not set.", tabs = indent_value)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def copyFile(self,source_filename, remote_path, source_path = IGNORE_THIS, remote_filename = IGNORE_THIS, indent_value = 1):
        """
          Copy a remote file on the network host at another location on the same network host 
           
        Args:
            source_filename (str): the name of the source file
            remote_pat (str): the destination path where the file should be copied
            source_path (str, optional): the source path where the source file should be read, if not specified it will be read from current directory
            remote_filename (str, optional): the name of the file on the network host, if not specified the same name than the source filename will be used.
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to copy the file otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Copy a file",indent_value)
        indent_value += 1

        if self.__connected:
            local_file  = source_filename
            remote_file = source_filename
            if source_path != IGNORE_THIS:
                local_file = source_path + "/" + local_file
            if remote_filename != IGNORE_THIS:
                remote_file = remote_filename
            remote_file = remote_path + "/" + remote_file
            self.logThis(f"Copying {local_file} to {remote_file}", tabs = indent_value)
            try:
                command_to_execute = "cp " + local_file + " " + remote_file
                if self.executeSSHCommand(command_to_execute, indent_value + 1):
                    self.logThis("File copied ", command_to_execute, tabs = indent_value + 2)
                    result = True
                else:
                    self.logThis("Can't copy the file", command_to_execute, tabs = indent_value + 2)
            except Exception as e:
                self.logThis(f"Unhandled error occured : {e}", tabs = indent_value + 1)
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return result

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def createDirectory(self,directory_name, root_path = IGNORE_THIS,create_full_path = False, indent_value = 1):
        """
          Create a directory on the network host
           
        Args:
            directory_name (str): the name of the directory to create
            root_path (str): the root path of the directory to be create. 
            create_full_path (boolean, optional): if set to True then the full path will be created.
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to create the directory otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Create a directory",indent_value)
        indent_value += 1

        if self.__connected:
            directory_name = directory_name.rstrip("/")
            root_path      = root_path.rstrip("/")
            full_path = directory_name
            if root_path != IGNORE_THIS:
                self.logThis(f"Creating {directory_name} in {root_path}", tabs = indent_value)
                full_path = root_path + "/" + directory_name
            else:
                self.logThis(f"Creating {directory_name}", tabs = indent_value)

            try:
                # Check if the directory exists 

                command_to_execute = "ls " + full_path
                if self.executeSSHCommand(command_to_execute, indent_value + 1):
                    self.logThis("Directory exists ", command_to_execute, tabs = indent_value + 2)
                    result = True
                else:
                    self.logThis("Directory doesn't exists", command_to_execute, tabs = indent_value + 2)
                    if create_full_path:
                        command_to_execute = "mkdir -p " + full_path
                    else:
                        command_to_execute = "mkdir " + full_path
                    
                    if self.executeSSHCommand(command_to_execute, indent_value + 4):
                        self.logThis("Directory created ", command_to_execute, tabs = indent_value + 3)
                        result = True
                    else:
                        self.logThis("Directory doesn't exists", command_to_execute, tabs = indent_value + 3)





            except Exception as e:
                self.logThis(f"Unhandled error occured : {e}", tabs = indent_value + 1)
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return result

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def prepareForWebSocketConnection(self, websocket_message_handler, indent_value = 1):
        """
          Prepares the Host for a Websocket connection
           
        Args:
            message_handler_method (callable): the name of the method to use when a message is received 
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return always True 
        """
        result = False

        self.beginMethodSeparator("Prepare the websocket",indent_value)
        indent_value += 1

        self.websocket_message_handler = websocket_message_handler
        self.websocket_uri             = "ws://" + self.__fqdn + ":" + str(self.__tcp_port_to_test)
        self.websocket_id              = None
        self.__connected               = False
        self.websocket_listener_task   = None

        self.logThis("Websocket uri is ", self.websocket_uri, tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    async def connectToWebsocket(self, indent_value = 1):
        """
          Connects to the websocket
           
        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to connect the websocket otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Connect to websocket",indent_value)
        indent_value += 1
        self.__checkConnectivity(self.__tcp_port_to_test,indent_value + 2)

        if self.isReachable():
            try:
                self.logThis("Connecting to ", self.websocket_uri, tabs = indent_value)
                self.websocket_id = await websockets.connect(self.websocket_uri,ping_interval=1, ping_timeout=10)
                self.logThis("Connected", tabs = indent_value + 1)
                self.__connected = True
                self.websocket_listener_task = asyncio.create_task(self.listen_to_server())
            except websockets.exceptions.ConnectionClosedError as e:
                self.logThis(f"Connection closed unexpectedly: {e}", tabs=indent_value + 1)
            except websockets.exceptions.InvalidURI as e:
                self.logThis(f"Invalid WebSocket URI: {e}", tabs=indent_value + 1)
            except websockets.exceptions.InvalidHandshake as e:
                self.logThis(f"Invalid WebSocket handshake: {e}", tabs=indent_value + 1)
            except Exception as e:
                self.logThis(f"Failed to connect to the server: {e}", tabs = indent_value + 1)
        else: 
            self.logThis("Server not reachable", tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    async def listen_to_server(self):
        """
        Continuously listen for messages from the WebSocket server.
        """
        try:
            async for message in self.websocket_id:
                await self.websocket_message_handler(message)  
        except websockets.ConnectionClosed:
            self.logThis("Connection closed by the server.")
            self.__connected = False
        except Exception as e:
            self.logThis(f"Error while receiving messages: {e}")

    async def sendMessageToWebSocket(self, message, indent_value = 1):
        """
          Send a message to the remote host using a websocket 
           
        Args:
            message (str): the message to be sent 
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return always True 
        """
        result = False

        self.beginMethodSeparator("Send message through the websocket",indent_value)
        indent_value += 1
        try:
            self.logThis("Message to send ", message, tabs = indent_value)
            if isinstance(message, dict):
                message = message.json.dumps(message)

            if self.websocket_id and not self.websocket_id.state == "closed":
                await self.websocket_id.send(message)
                self.logThis("Message sent ", message, tabs = indent_value)
                # await asyncio.sleep(0.01)
            else:
                self.logThis("Cannot send message. WebSocket is not connected.", tabs = indent_value)
                await self.connectToWebsocket()

        except websockets.exceptions.ConnectionClosedError:
            self.logThis("WebSocket is closed.", tabs = indent_value)



        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    async def disconnectWebsocket(self):
        """
        Disconnect from the WebSocket server and cancel the listener task.
        """
        if self.listener_task:
            self.listener_task.cancel()
            try:
                await self.listener_task
            except asyncio.CancelledError:
                pass

        if self.websocket:
            await self.websocket.close()
            print("Disconnected from the server.")

    def methodTemplate(self, indent_value = 1):
        """
          What it does
           
        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to create all the VMs otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Change the method name",indent_value)
        indent_value += 1

        # Put here all the method logic
        self.logThis("Log a message", tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    