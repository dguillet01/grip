"""
APICaller: A Simple Library for executing file management
Author: David Guillet
Creation Date: Dec. 13 2022
Last Modified Date: Apr. 29 2025
Version: 1.0.3
Version History :
    1.0.0 : Initial release
    1.0.1 : Added the saveDictionary method to save the content of a dictionary to the file
    1.0.2 : Added a test if file exists before closing it    
    1.0.3 : Added a method to write a binary content to file + adding a boinary parameter for the openFileForWriting method
    
Improvements :
    - 
    
# !/usr/bin/env python3.10
# coding: utf-8
"""


from modules.debugging import *
import re
import json 
import time


_FILE_READONLY       = "r"
_FILE_READWRITE      = "w"
_DEFAULT_OPEN_MODE   = "r"

_LOGFILE_PREFIX = 'File_'

class File(Debugging):
    # MAX_LENGTH_FOR_DUMP = 10
    # internal constants 

    def __init__(self,filename, debug_activation=DEFAULT_DEBUGGING_STATE, path_for_log_file= DEFAULT_PATH_FOR_LOGFILE, debug_type=DEFAULT_DEBUGGING_TYPE):

        super().__init__(_LOGFILE_PREFIX + filename, path_for_log_file,debug_activation, debug_type )
        self.__filename   = filename
        self.lines        = []
        self.currentLine  = -1 
        self.dataLoaded   = False
        self.data         = IGNORE_THIS
        self.__fileExists = os.path.exists(self.__filename)
        self.fileIsOpen   = False

        self.beginMethodSeparator("File Object creation")
        self.logThis("Filename is ",parameter_value=self.__filename,tabs = 1)
        self.logThis("Working directory is ",parameter_value=os.getcwd(),tabs = 1)
        # self.logThis("User is ",parameter_value=os.getlogin(),tabs = 1)

        self.endMethodSeparator()

    def dump(self,indent_value = 1):
        self.logThis("\n\n\n", parameter_value=self, tabs = indent_value + 1)
        self.logThis("Dumping instance", tabs = indent_value + 1)
        maxLength = 0
        for elementKey, elementValue in self.__dict__.items():
            currentLenth = len(elementKey)
            maxLength = currentLenth if currentLenth > maxLength else maxLength
        self.logThis("Dumping File Instance ... ", parameter_value=self.__dict__, tabs = indent_value + 1,max_log_message_length=maxLength)
    
    def toggleDebug(self):
        self.__debug.toggleDebug()
        
    def openFileForReading(self, indent_value = 1):
        self.beginMethodSeparator("Opening file for reading", tabs = indent_value)
        self.logThis("Check if file " + self.__filename + " exists", tabs = indent_value + 1)

                # Open the file and store the file descriptor
        if os.path.exists(self.__filename):
            self.__fileExists = True
            self.logThis("Filename exists, opening it ... ",tabs = indent_value + 2)
        
        if self.__fileExists:
            self.logThis("Continuing ... ",tabs = indent_value + 2)
        
            try:
                self.logThis("Filename exists, opening it ... ",tabs = indent_value + 2)
                self.__file_descriptor = open(self.__filename, 'r')
                # Set the fileIsOpen attribute to True
                self.logThis("Filename is open and ready to be read ... ",tabs = indent_value + 2)
                self.fileIsOpen = True
                # Return True to indicate that the file was successfully opened
                self.endMethodSeparator(indent_value)
                return True

                            # If an IOError occurs, print an error message and return False
            except FileNotFoundError:
                print(f"Error: File '{self.__filename}' not found.")
                self.__file_descriptor = None  # Avoid using an uninitialized variable
            except PermissionError:
                print(f"Error: Permission denied for file '{self.__filename}'.")
                self.__file_descriptor = None
            except Exception as e:
                print(f"An unexpected error occurred: {e}")
                self.__file_descriptor = None

            except IOError as theError:
                self.logThis("Filename doesn't exists or can't be opened ... ",IOError, tabs = indent_value + 2)
                self.__file_descriptor = None
                self.fileIsOpen = False
                self.endMethodSeparator(indent_value)
                return False
            except Exception as e:
                self.logThis("Filename doesn't exists or can't be opened ... ",e, tabs = indent_value + 2)
                self.__file_descriptor = None
                self.fileIsOpen = False
                self.endMethodSeparator(indent_value)
                return False
        else:
            self.logThis("File doesn't exists ",tabs = indent_value + 2)

        sys.exit()

    def openFileForWriting(self, overwrite=True, createPath=True, binary=False,indent_value = 1):
        try:
            self.beginMethodSeparator("Opening file for writing",indent_value)
            indent_value += 1
            # Create the path for the file if createpath is True

            if os.path.dirname(self.__filename):
                self.logThis("Filename is located at " + os.path.dirname(self.__filename) ,tabs = indent_value)
            else:
                self.logThis("Filename is located at " + os.getcwd() ,tabs = indent_value)
                


            if createPath and os.path.dirname(self.__filename):
                self.logThis("Creating the directory " + os.getcwd() + "/" + os.path.dirname(self.__filename),tabs = indent_value)
                os.makedirs(os.path.dirname(self.__filename), exist_ok=True)

            # Open the file for appending or writing and depending on data to write add the binary mode 
            if binary:
                mode = "wb" if overwrite else "ab"
            else:
                mode = "w" if overwrite else "a"

            # self.dump()
            self.logThis("File open mode is set to " + mode ,tabs = indent_value)
            self.logThis("Trying to open file ... ",tabs = indent_value)
            if binary:
               self.__file_descriptor = open(self.__filename, mode)
            else:
               self.__file_descriptor = open(self.__filename, mode,buffering=1)

            self.__fileExists = True
        except Exception as error:
            # Print the error message and exit the program
            self.logThis("Filename doesn't exists or can't be opened ... ", str(error),tabs = indent_value + 1)
            self.fileIsOpen = False
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return False

        self.logThis("File is open ... ",tabs = indent_value + 1)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        self.fileIsOpen = True

        return True

    def closeFile(self, indent_value = 1):
        result = False
        self.beginMethodSeparator("closeFile ",indent_value)
        indent_value += 1
        if self.__fileExists:
            try:
                # Closing the file if it is open 
                if self.fileIsOpen:
                    self.logThis("Closing ... ",tabs = indent_value)
                    self.__file_descriptor.flush()
                    os.fsync(self.__file_descriptor.fileno())
                    self.__file_descriptor.close()
                    # time.sleep(10)

                    
                    # # Force synchronization to ensure all changes are written to disk
                    # try:
                    #     os.sync()  # Sync filesystem
                    # except AttributeError:
                    #     # os.sync() might not be available on some systems (e.g., Windows).
                    #     self.logThis("Filesystem synchronization is not supported on this platform.")
                    # finally:
                    #     result = True
                    #     self.logThis("File is closed !",tabs = indent_value + 1)
                    result = True
                    self.logThis("File is closed !",tabs = indent_value + 1)
            except Exception as error:
                # Print the error message and exit the program
                self.logThis("Error when closing file ... ",tabs = indent_value + 1)
                self.fileIsOpen = False
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return result
        else:
            self.logThis("File not open ")
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        self.fileIsOpen = False
        return True

    def readContent(self, indent_value = 1):
        try:
            self.beginMethodSeparator("Reading file content",indent_value)
            indent_value += 1

            if self.fileIsOpen:
                self.logThis("Reading file content ... ",tabs = indent_value + 1)
                # self.arrayOfLines = self.__file_descriptor.readlines()
                for currentLine in self.__file_descriptor:
                    currentLine = currentLine.rstrip('\n')
                    self.lines.append(currentLine)
            else:
                self.logThis("File is not opened can't read anything ... ",tabs = indent_value + 1)
        except Exception as error:
            # Print the error message and exit the program
            self.logThis("Error " + str(error) + " while reading file ... ",tabs = indent_value + 1)
            indent_value -= 1
            self.closeFile(indent_value + 2)
            self.endMethodSeparator(indent_value)
            return False
        self.dataLoaded = True
        self.logThis("File content loaded closing the file ... ",tabs = indent_value + 1)
        self.closeFile(indent_value + 2)
        self.currentLine = 0
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return True

    def readJSONContent(self, indent_value = 1):
        """
            Reads JSON content from file.

            Returns:
                result (Boolean or JSON structure): JSON content if file contains a JSON structure False otherwise.
                
            Raises:
                Nothing 
            
        """
        self.beginMethodSeparator("Reading file content as JSON",indent_value)
        indent_value += 1
        result = False
        try:
            if self.fileIsOpen:
                self.logThis("Reading JSON file content ... ",tabs = indent_value + 1)
                self.data = json.load(self.__file_descriptor)
                self.dataLoaded = True
                self.logThis("JSON content loaded closing the file ... ",tabs = indent_value + 1)

        except Exception as errorDescription:
            # Print the error message and exit the program
            self.logThis("Error decoding JSON ",parameter_value=str(errorDescription), tabs = indent_value + 2)
            self.closeFile(indent_value + 2)
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return False

        indent_value -= 1
        self.closeFile(indent_value + 2)
        self.endMethodSeparator(indent_value)
        return self.data

    def getCurrentLineNumber(self, indent_value = 1):
        self.beginMethodSeparator("getCurrentLineNumber",indent_value)
        result = self.currentLine
        self.endMethodSeparator(indent_value)
        return result

    def readNextLine(self, lineNumber = -1, indent_value = 1):
        """
            Reads a specific line from the file, or the current line if 'lineNumber' is not provided.
            
            Parameters:
                lineNumber (int): The line number to be read. if not provided method will use the current line pointer as the line number to read.
                indent_value (int): the level of indentation for the debug logs can be omitted as default is 1
            
            Returns:
                result (str): The contents of the specified line or the current line pointer from the file. If the lineNumber or the current line pointer is above the bondaries of the file method will return IGNORE_THIS value
        """
        self.beginMethodSeparator("Starting readLine",indent_value)
        indent_value += 1
        result = IGNORE_THIS

        lineNumberToRead = lineNumber

        if self.dataLoaded:
            if lineNumberToRead == -1:
                self.logThis('Setting line number to ', parameter_value = self.currentLine  ,tabs = indent_value)
                lineNumberToRead = self.currentLine
            self.logThis('Reading line ', parameter_value= lineNumberToRead  ,tabs = indent_value)
            if lineNumberToRead <= len(self.lines) - 1:
                self.logThis('Reading ', parameter_value = self.lines[lineNumberToRead] ,tabs = indent_value + 1)
                result = self.lines[lineNumberToRead]
            else:
                self.logThis('Trying to read outside File bondaries ...' + str(result) ,tabs = indent_value + 1)
            self.logThis('Returning ' + result ,tabs = indent_value)
            if lineNumber > -1: 
                self.currentLine = lineNumberToRead + 1        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def readLine(self, lineNumber = -1, indent_value = 1):
        """
            Reads a specific line from the file, or the current line if 'lineNumber' is not provided.
            
            Parameters:
                lineNumber (int): The line number to be read. if not provided method will use the current line pointer as the line number to read.
                indent_value (int): the level of indentation for the debug logs can be omitted as default is 1
            
            Returns:
                result (str): The contents of the specified line or the current line pointer from the file. If the lineNumber or the current line pointer is above the bondaries of the file method will return IGNORE_THIS value
        """
        self.beginMethodSeparator("Starting readLine",indent_value)
        indent_value += 1
        result = IGNORE_THIS

        if self.dataLoaded:
            if lineNumber == -1:
                self.logThis('Setting line number to ', parameter_value = self.currentLine  ,tabs = indent_value)
                lineNumber = self.currentLine
            self.logThis('Reading line ', parameter_value= lineNumber  ,tabs = indent_value)
            if lineNumber <= len(self.lines) - 1:
                self.logThis('Reading ', parameter_value = self.lines[lineNumber] ,tabs = indent_value + 1)
                result = self.lines[lineNumber]
            else:
                self.logThis('Trying to read outside File bondaries ...' + str(result) ,tabs = indent_value + 1)
            self.logThis('Returning ' + result ,tabs = indent_value)
            self.currentLine = lineNumber + 1        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def lineContainsSearchString(self, searchThis = IGNORE_THIS, lineNumber = -1, indent_value = 1):
        self.beginMethodSeparator("Starting lineContainsSearchString",indent_value)
        indent_value += 1
        result = False

        if self.dataLoaded:
            if not(searchThis == IGNORE_THIS):
                if lineNumber == -1:
                    self.logThis('Setting line number to ', parameter_value = self.currentLine  ,tabs = indent_value)
                    lineNumber = self.currentLine
                if lineNumber <= len(self.lines) - 1:
                    lineRead = self.lines[lineNumber]
                    self.logThis('Looking for ' + searchThis + 'in line ' + lineRead,tabs = indent_value)
                    if searchThis in lineRead:
                        self.logThis('Found it !',tabs = indent_value + 1)
                        result = True
                    else:
                        self.logThis('Not found !',tabs = indent_value + 1)
                    # result = self.lines[lineNumber]
                else:
                    self.logThis('Trying to read outside File bondaries ...' + result ,tabs = indent_value + 1)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def lineMatchRegularExpression(self, matchThis = IGNORE_THIS, lineNumber = -1, indent_value = 1):
        self.beginMethodSeparator("Starting lineMatchRegularExpression",indent_value)
        indent_value += 1
        result = False

        if self.dataLoaded:
            if not(matchThis == IGNORE_THIS):
                if lineNumber == -1:
                    self.logThis('Setting line number to ', parameter_value = self.currentLine  ,tabs = indent_value)
                    lineNumber = self.currentLine
                if lineNumber <= len(self.lines) - 1:
                    lineRead = self.lines[lineNumber]
                    self.logThis('Looking if ' + lineRead + 'matches this ' + matchThis,tabs = indent_value)
                    if re.match(matchThis, lineRead):
                        self.logThis('Found it !',tabs = indent_value + 1)
                        result = True
                    else:
                        self.logThis('Not found !',tabs = indent_value + 1)
                    # result = self.lines[lineNumber]
                else:
                    self.logThis('Trying to read outside File bondaries ...' + result ,tabs = indent_value + 1)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def goToLineContaining(self, matchThis = IGNORE_THIS, lineNumber = -1, indent_value = 1):
        self.beginMethodSeparator("Starting goToLineContaining",indent_value)
        indent_value += 1
        result = False
        carryOn = True
        found = False

        if self.dataLoaded:
            if not(matchThis == IGNORE_THIS):
                if lineNumber == -1:
                    self.logThis('Setting line number to ', parameter_value = self.currentLine  ,tabs = indent_value)
                    lineNumber = self.currentLine
                while carryOn:
                    if lineNumber <= len(self.lines) - 1:
                        lineRead = self.lines[lineNumber]
                        self.logThis('Looking if ' + lineRead + ' matches this ' + matchThis,tabs = indent_value)
                        if re.match(matchThis, lineRead):
                            self.logThis('Found it !',tabs = indent_value + 1)
                            found = True
                            carryOn = False
                        else:
                            self.logThis('Not found !',tabs = indent_value + 1)
                        # result = self.lines[lineNumber]
                    else:
                        self.logThis('Trying to read outside File bondaries ...' + str(result) ,tabs = indent_value + 1)
                        carryOn = False
                    lineNumber += 1
        indent_value -= 1
        if found:
            self.currentLine = lineNumber
        self.endMethodSeparator(indent_value)
        return result

    def saveDictionary(self,dictionary,indent_value = 1):
        """
            Save the content of a dictionary into the file in a JSON format.
            
            Parameters:
                dictionary : The dictionary to save 
                indent_value (int): the level of indentation for the debug logs can be omitted as default is 1
            
            Returns:
                Returns true if the dictionary was save otherwise it returns false. 
        """
        self.beginMethodSeparator("saveDictionary",indent_value)
        indent_value += 1
        result = False
        
        if self.fileIsOpen:
            json.dump(dictionary, self.__file_descriptor, indent=4)
            result = True

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result    

    def saveBinary(self,binary_content,indent_value = 1):
        """
            Save a binary data into the file in a JSON format.
            
            Parameters:
                binary_content : The binary content to be saved 
                indent_value (int): the level of indentation for the debug logs can be omitted as default is 1
            
            Returns:
                Returns true if the binary data was save otherwise it returns false. 
        """
        self.beginMethodSeparator("saveBinary",indent_value)
        indent_value += 1
        result = False
        
        if self.fileIsOpen:
            self.__file_descriptor.write(binary_content)
            result = True

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result    


    def writeLine(self, line, indent_value = 1):
        result = False
        
        if self.fileIsOpen:
            self.logThis('Writing ',line ,tabs = indent_value)
            self.__file_descriptor.write(line + '\n')
            result = True

        return result