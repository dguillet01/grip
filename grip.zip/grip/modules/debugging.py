"""
Logging: A Simple Library to log debug messages
Author: David Guillet
Creation Date: Nov. 20 2023
Last Modified Date: Apr. 2 2025
Version: 1.0.6
Version History :
    1.0.0 : Initial release (Copy from previous projects)
    1.0.1 : Use enum now to encode the debugging targets 
    1.0.2 : Remove the use of enum switching back to plain old object to encode debugging targets 
    1.0.3 : Adding methods to handle script execution status 
    1.0.4 : Adding method to get the path for log file 
    1.0.5 : Few change in the the logThis method to have the table index display properly as the table.index function did not work well 
    1.0.6 : Few change in the the logThis method to call the dump method if this is a personnal object that has a dump method 
"""
import os
import sys 
import re

class DEBUG_TARGET():
    """
    Enumeration representing the possible debug message output targets.

        Defined in : \n
    \tdebuging.py \n

    Members:
    - TO_FILE: used to display all the log message to a specified file\n
    - TO_SCREEN: used to display all the log message to the screen\n
    - TO_STDERR: used to display all the log message to the standard error output stream"""

    TO_FILE = "toFile"
    """
    \tThis value is used to display all the log message to a specified file\n
    """
    TO_SCREEN = "ToScreen"
    """
    \tThis value is used to display all the log message to the screen\n
    """
    TO_STDERR = "ToStdErr"
    """
    \tThis value is used to display all the log message to the standard error output stream"""

# Global constants 
IGNORE_THIS = "IgnoreThis"
"""
Defined in : \n
\tdebuging.py \n
Description : \n
\tThis value can be assigned to a variable anywhere \n
\tIt is a specific value that can be used to check if the content of the variable can be ignored or if it is set to this variable a specific action can be triggered\n"""

DEFAULT_DEBUGGING_STATE = True
"""
Defined in : \n
\tdebuging.py \n
Description : \n
\tThis the default value for the debugging activation.\n
\tIt is set to True so message logging is enabled by default.\n 
\tIf you want to change it globally then edit the debuging.py file and set it to FALSE and don't forget to change this message"""
DEFAULT_DEBUGGING_TYPE = DEBUG_TARGET.TO_SCREEN
"""
Defined in : \n
\tdebuging.py \n
Description : \n
\tThis the default value for the debugging output.\n
\tIt is set to display the message to the screen if logging is enabled.\n 
\tIf you want to change it globally then edit the debuging.py file and set it to the desired value and don't forget to change this message"""

DEFAULT_PATH_FOR_LOGFILE = "logs/"
"""
Defined in : \n
\tdebuging.py \n
Description : \n
\tThis the default value for the path where the log files are stored.\n
\tBy default it is set store the log files to the logs/ directory at the root of your project.\n 
\tIf you want to change it globally then edit the debuging.py file and set it to the desired value and don't forget to change this message"""

STATUS_MESSAGE_SEPARATOR = ";"
"""
Defined in : \n
\tdebuging.py \n
Description : \n
\tThis the default value for the status separator.\n
\tBy default it is set ";" .\n 
\tIf you want to change it globally then edit the debuging.py file and set it to the desired value and don't forget to change this message"""

class Debugging:
    def __init__(self,debug_file_name=IGNORE_THIS, path_for_log_file= DEFAULT_PATH_FOR_LOGFILE,debug_activation=DEFAULT_DEBUGGING_STATE, debug_type : DEBUG_TARGET=DEFAULT_DEBUGGING_TYPE):
        """
        The `Debuging` class provides a simple interface for logging debug messages to a file, the screen, or the standard error output stream.

        Parameters:
            - debug_fileName     (str) : The name of the debug file. Defaults to IGNORE_THIS.
            - path_for_log_file (str) : The path for the log file. Defaults to DEFAULT_PATH_FOR_LOGFILE.
            - debug_activation  (bool): The activation state of debugging. Defaults to DEFAULT_DEBUGGING_STATE.
            - debug_type        (DEBUG_TARGET) : The type of debugging. Defaults to DEFAULT_DEBUGGING_TYPE.

        """
        log_target_message       = ""
        self.__is_activated      = debug_activation
        self.__debug_type        = debug_type
        self.__debug_file_name   = debug_file_name.replace(" ", "_")
        self.__debug_file_name   = self.__debug_file_name.replace("/", "_") + ".log"
        self.__path_for_log_file = path_for_log_file
        self.__status_file       = None        
       
        match debug_type:
            case DEBUG_TARGET.TO_SCREEN:
                log_target_message = "debugging is set to display debug messages to screen"
            case DEBUG_TARGET.TO_STDERR:
                log_target_message = "debugging is set to display debug messages to stderr"
            case DEBUG_TARGET.TO_FILE:
                self.__openDebugFile()
                log_target_message = "debugging is set to display debug messages to file " + self.__path_for_log_file + self.__debug_file_name
            case _:
                log_target_message = "debugging type " + str(debug_type) + " is unknown"

        self.beginMethodSeparator("Debugger object creation")
        self.logThis(log_target_message, tabs = 1)

    def switchToScreen(self):
        """
        This function changes the debugging type to display debugging message to screen and stores the debugging type 
        """
        self.logThis("Switching debugging to Screen", tabs = 1)
        self.__previous_type = self.__debug_type
        self.__debug_type = DEBUG_TARGET.TO_SCREEN
        self.logThis("Now debugging to Screen", tabs = 1)

    def switchBack(self):
        """
        This function restores previous debugging type to display debugging message to it
        """
        self.logThis("Switching back to previous mode", tabs = 1)
        self.__debug_type = self.__previous_type

    def toggleDebug(self):
        """
        This function toggles the debugging state to True if it was False and vice versa.
        """
        if self.__is_activated:
            self.__is_activated = False
        else:
            self.__is_activated = True 

    def __openDebugFile(self):
        """
        Tries to open the debug file 
          for writing.
        
        If the file is successfully opened it returns `True`, otherwise it prints an error message to `sys.stderr` and returns `False`,
        
        If the path to the file does not exist and is not empty, it will be created.

        """
        # Try to open the file specified by the internal property __debugFileName attribute for writing
        try:
            # Get the directory of the file using the os.path module
            file_path = os.path.dirname(self.__path_for_log_file + self.__debug_file_name)

            # If a file path was returned and the directory does not already exist, create the directory
            if file_path and not os.path.exists(file_path):
                os.makedirs(file_path)

            # Open the file for writing and store the file descriptor
            self.__file_descriptor = open(self.__path_for_log_file + self.__debug_file_name, 'w')

            # Set the fileIsOpen attribute to True
            self.__file_is_open = True

            # Return True to indicate that the file was successfully opened
            return True

        # If an IOError occurs, print an error message and return False
        except IOError as theError:
            print("Error opening log file:", theError, file=sys.stderr)
            self.__file_descriptor = None
            self.__file_is_open = False
            return False

    def __logIt(self, message, tabs):
        """
        Log a message to the specified output destination.

        This method logs a message to the output destination specified by the `debugType` attribute of the `Debugging` class. The output destination can be the screen, a file, or the standard error stream (stderr). The message is indented by a number of tabs specified by the `tabs` argument.

        Args:
            message (str): The message to log.
            tabs (int): The number of tabs to indent the message by.

        Returns:
            None
        """

        # Check the value of the debugType attribute
        if self.__debug_type == DEBUG_TARGET.TO_SCREEN:
            # If the debugType isDEBUGGING_TO_SCREEN, print the message to the screen
            print("| " +"\t| " * tabs + message + "\n", end="", flush=True)
        elif self.__debug_type == DEBUG_TARGET.TO_FILE:
            # If the debugType isDEBUGGING_TO_FILE, write the message to the file specified by the fileDescriptor attribute
            if self.__file_is_open:
                self.__file_descriptor.write("| " +"\t| " * tabs + message + "\n")
                self.__file_descriptor.flush()
                
        elif self.__debug_type == DEBUG_TARGET.TO_STDERR:
            # If the debugType isDEBUGGING_TO_STDERR, print the message to the standard error stream
            print("| " +"\t| " * tabs + message + "\n", file=sys.stderr, end="", flush=True)
        else:
            # If the debugType is unknown, print an error message
            print("debugging type %s is unknown",self.__debug_type, flush=True)

    def dump(self, indent_value = 1):
        """
        Dumps the instance of the class and its attributes
        :param indent_value: the number of tabs before each log message
        """
        self.logThis("\n\n\n", parameter_value=self, tabs = indent_value + 1)
        # self.logThis("Dumping instance", parameter_value= toto, tabs = indent_value + 1)
        maxLength = 0
        for elementKey, elementValue in self.__dict__.items():
            currentLenth = len(elementKey)
            maxLength = currentLenth if currentLenth > maxLength else maxLength
        self.logThis(f"Dumping {self.__class__.__name__} Instance ... ", parameter_value=self.__dict__, tabs = indent_value + 1,max_log_message_length=maxLength)

    def logThis(self, log_message, parameter_value = IGNORE_THIS, tabs: int = 0, first_iteration = True, max_log_message_length = 0 ):
        """
        This method logs a message and if specified any variable. The output of the log message depends on the debugType internal parameter.
        For tables and dictionaries the method will recurse into all the contents of the variable and will even display inner tables or dictionaries. 
        
        Parameters:
            - log_message (str)                      : The message to be logged.
            - parameter_value (Any, optional)        : This is the variable that will be displayed right after the log message. If it is a table or a dictionary the method will loop into itself to display all the content of the variable.
            - tabs (int, optional)                   : The number of tabs to include before the log message. Defaults to 0.
            - first_iteration (bool, optional)       : Indicates if the log message have to be displayed before the variable or not. Defaults to True.
            - max_log_message_length (int, optional) : The maximum length of the log message. It truncates the log message. This can be used when logging multiple variables and have them aligned. By default it is set to display the full log message.
        """
        if self.__is_activated:
            if (parameter_value == IGNORE_THIS):
                self.__logIt(log_message, tabs)
            else:
                if isinstance(parameter_value, str):
                    if max_log_message_length > 0:
                        message = "{:.{}}".format(log_message, max_log_message_length)
                        number_of_spaces = max_log_message_length - len(message)
                        message = message + " " * number_of_spaces
                    else:
                        message = log_message
                    self.__logIt(message + " : " + parameter_value, tabs)
                elif isinstance(parameter_value, int):
                    if max_log_message_length > 0:
                        message = "{:.{}}".format(log_message, max_log_message_length)
                        number_of_spaces = max_log_message_length - len(message)
                        message = message + " " * number_of_spaces
                    else:
                        message = log_message
                    self.__logIt(message + " : " + str(parameter_value), tabs)
                elif isinstance(parameter_value, list):
                    if first_iteration: self.__logIt(log_message, tabs)
                    item_index = 0
                    for list_index in parameter_value:
                        # item_index = parameter_value.index(list_index)
                        if item_index < 10:
                            item_index_str = "000" + str(item_index)
                        elif item_index < 100:
                            item_index_str = "00" + str(item_index)
                        elif item_index < 1000:
                            item_index_str = "0" + str(item_index)
                        else:
                            item_index_str = str(item_index)                           

                        if max_log_message_length > 0:
                            # message = "[" + str(parameterValue.index(list_index)) 
                            message = "[" + item_index_str
                            message = "{:.{}}".format(message, max_log_message_length + 1)
                            number_of_spaces = (max_log_message_length + 2) - len(message)
                            message = message + "]" + " " * number_of_spaces
                        else:
                            # message = "[" + str(parameterValue.index(list_index)) + "]"
                            message = "[" + item_index_str + "]"

                        if isinstance(list_index, (list, dict)):
                            self.__logIt(message + " = ", tabs)
                            self.logThis(log_message, list_index, tabs + 1, False,max_log_message_length=max_log_message_length)
                        else:
                            if hasattr(list_index, "dump") and callable(getattr(list_index, "dump")):
                                self.__logIt(message + " = ", tabs + 1)
                                list_index.dump(tabs + 2)
                            else:
                                self.__logIt(message + " = " + str(list_index), tabs)
                        item_index = item_index + 1
                elif isinstance(parameter_value, dict):
                    if first_iteration: self.__logIt(log_message, tabs)
                    if len(parameter_value) > 0:
                        mx_key_length = max(len(key) for key in parameter_value.keys())
                    else:
                        mx_key_length = 0
                    
                    for elementKey, elementValue in parameter_value.items():
                        if max_log_message_length > 0:
                            message = "{" + elementKey 
                            message = "{:.{}}".format(message, max_log_message_length + 1)
                            number_of_spaces = (max_log_message_length + 2) - len(message)
                            message = message + "}" + " " * number_of_spaces
                        else:
                            message = "{" + elementKey 
                            message = "{:.{}}".format(message, mx_key_length + 1)
                            number_of_spaces = (mx_key_length + 2) - len(message)
                            message = message + "}" + " " * number_of_spaces
                            
                            # message = "{" + elementKey + "}"

                        if isinstance(elementValue, (list, dict)):
                            message = "{" + elementKey + "}"
                            self.__logIt(message + " => ", tabs)
                            self.logThis(log_message, elementValue, tabs + 1, False,max_log_message_length=0)
                        else:
                            if hasattr(elementValue, "dump") and callable(getattr(elementValue, "dump")):
                                self.__logIt(message + " => ", tabs + 1)
                                elementValue.dump(tabs + 2)
                            else:
                                self.__logIt(message + " => " + str(elementValue), tabs)
                # else:
                #     if hasattr(parameter_value, "dump") and callable(getattr(parameter_value, "dump")):
                #         parameter_value.dump(tabs + 1)

    def beginMethodSeparator(self, methodName : str, tabs: int = 0):
        """
        This method prints a separator line and a message indicating the start of the specified method.

        :param methodName (str): The name of the method that is starting
        :param tabs (int): The number of tabs to insert before the log message (default is 0)
        :return: None
        """
        if self.__is_activated:
            self.__logIt("########################################################################", tabs)
            self.__logIt("# Starting method " + methodName, tabs)

    def endMethodSeparator(self, tabs: int = 0):
        """
        This method prints a separator line indicating the end of a method.

        :param tabs: The number of tabs to insert before the log message (default is 0)
        :return: None
        """
        if self.__is_activated:
            self.__logIt("########################################################################", tabs)
        
    def getDebuggingState(self, indent_value = 1):
        """
            This function returns the debugging state.
        """
        return self.__is_activated

    def getType(self, indent_value = 1):
        """
            This function returns the debugging type.
        """
        return self.__debug_type

    def getPathForLogFile(self, indent_value = 1):
        """
            This function returns the path where the log file is saved.
        """
        return self.__path_for_log_file
    
    def openStatusFileForWriting(self, filename : str, indent_value = 1):
        """
        This method opens in write mode a file where all execution steps for your scripts can be written. 
        
        Parameters:
            - filename (str)               : The message to be logged.
            - indent_value (int, optional) : The number of tabs to include before the log message. Defaults to 0.

        Returns:
            Return True if the file is open otherwise it returns false.
        """
        self.beginMethodSeparator("Open status file for writing ",tabs = indent_value)
        indent_value += 1
        result = False

        try:
            if os.path.dirname(filename):
                os.makedirs(os.path.dirname(filename), exist_ok=True)

            self.logThis("Opening file ", filename ,tabs = indent_value)
            self.__status_file = open(filename, "w")
            result = True
        except Exception as error:
            # Print the error message and exit the program
            self.logThis("Filename doesn't exists or can't be opened ... ", str(error),tabs = indent_value + 1)
            self.__status_file = False
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return False

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def openStatusFileForReading(self, filename : str, indent_value = 1):
        """
        This method opens in read mode a file where all execution steps for your scripts are stored. 
        
        Parameters:
            - filename (str)               : The status filename.
            - indent_value (int, optional) : The number of tabs to include before the log message. Defaults to 0.

        Returns:
            Return True if the file is open otherwise it returns false.
        """
        self.beginMethodSeparator("Open status file for reading",tabs = indent_value)
        indent_value += 1
        result = False

        # self.__status_file = File(filename,debug_activation=self.getDebuggingState(), path_for_log_file=self.__path_for_log_file, debug_type=self.getType())
        try:
            self.logThis("Opening file ", filename ,tabs = indent_value)
            self.__status_file = open(filename, "r")
            self.logThis("File is open", self.__status_file ,tabs = indent_value)
            result = True
        except Exception as error:
            # Print the error message and exit the program
            self.logThis("Filename doesn't exists or can't be opened ... ", str(error),tabs = indent_value + 1)
            self.__status_file = False
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return False

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
       
    def closeStatusFile(self, indent_value = 1):
        """
        This method closes the status file.
        
        Parameters:
            - indent_value (int, optional) : The number of tabs to include before the log message. Defaults to 0.

        Returns:
            Return True if the file is closed otherwise it returns false.
        """

        try:
            self.beginMethodSeparator("closeFile ",indent_value)
            indent_value += 1
            # Closing the file if it is open 
            if self.__status_file:
                self.logThis("Closing ... ",tabs = indent_value)
                self.__status_file.flush()
                os.fsync(self.__status_file.fileno())
                self.__status_file.close
                
        except Exception as error:
            # Print the error message and exit the program
            self.logThis("Error when closing file ... ",tabs = indent_value + 1)
            self.fileIsOpen = False
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return False
        
        self.logThis("File is closed !",tabs = indent_value + 1)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return True

    def writeStatus(self, status_description : str = IGNORE_THIS, status_state : str = IGNORE_THIS,status_code : int = 0, indent_value = 1):
        """
        This method writes in the status file the provided status. a json file where all execution steps for your scripts can be written. 
        
        Parameters:
            - status_description (str)     : The status description
            - status_state  (str)          : The sattus state
            - indent_value (int, optional) : The number of tabs to include before the log message. Defaults to 0.

        Returns:
            Return True if the status was writen otherwise it returns false.
        """
        self.beginMethodSeparator("write status ",tabs = indent_value)
        indent_value += 1
        result = False

        if self.__status_file:
            status_line = status_description + STATUS_MESSAGE_SEPARATOR + str(status_state) + STATUS_MESSAGE_SEPARATOR + str(status_code)+'\n'
            result = self.__status_file.write(status_line)
            self.__status_file.flush()
        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
 
    def readStatus(self, indent_value = 1):
        """
        This method reads all elements in the status file.
         
        Parameters:
            - indent_value (int, optional) : The number of tabs to include before the log message. Defaults to 0.

        Returns:
            Return all the lines in the file otherwise it returns false.
        """
        self.beginMethodSeparator("read status ",tabs = indent_value)
        indent_value += 1
        result = False

        try:
            if self.__status_file:
                self.logThis("Reading file content ... ",tabs = indent_value + 1)
                result = self.__status_file.read()
            else:
                self.logThis("File is not opened can't read anything ... ",tabs = indent_value + 1)
        except Exception as error:
            # Print the error message and exit the program
            self.logThis("Error " + str(error) + " while reading file ... ",tabs = indent_value + 1)
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return False
        self.logThis("File content loaded closing the file ... ",tabs = indent_value + 1)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    