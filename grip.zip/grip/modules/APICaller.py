"""
APICaller: A Simple Library for executing API calls
Author: David Guillet
Creation Date: Nov. 20 2023
Last Modified Date: Jan. 07 2024
Version: 1.0.8
Version History :
    1.0.0 : Initial release
    1.0.1 : Added the executeFromFile method and associated enumeration classes
    1.0.2 : Added the necessary processing of dictionary result 
    1.0.3 : Modification of the setAPIBodyContent
    1.0.4 : Bug corrections and improvements, added a method to execute oAuth API calls from a JSON file and a method to read all the results of multiple API calls
    1.0.5 : Added resultKey field on the JSON file for multiple API calls and the getResultForKey method
    1.0.6 : Added FQDN parameter to the  field on the JSON file for multiple API calls and the getResultForKey method
    1.0.7 : Added connection_port to the prepareHTTPSConnection method
    1.0.8 : Added method to read the execution code of the API call


Improvements :
    - Inherite from the network host class
    - Change the api call preparation task
    - Add some HTTP request parameters tests to be sure the request will have less chances to fail
"""

from modules.debugging import *
import http.client
import ssl
import os
import json
from urllib.parse import urlparse, urlencode

class MIME_FORMAT():
    """
    Enumeration representing the possible mime format for the HTTP Headers.

    Defined in:
    - APICaller.py

    Members:
    - NONE : Mime format empty
    - FORM : Mime format set to application/x-www-form-urlencoded.\n
    - JSON : Mime format set to application/json.\n
    """
    NONE = ''
    """
    \tUse this to clear the mime format of an HTTP request"""
    FORM = 'application/x-www-form-urlencoded'
    """
    \tUse this to set the mime format of an HTTP request to application/x-www-form-urlencoded.\n"""
    JSON = 'application/json'
    """
    \tUse this to set the mime format of an HTTP request to application/json.\n"""

class API_METHOD():
    """
    Enumeration representing the possible API method that can be used.

    Defined in:
    - APICaller.py

    Members:
    - POST   : POST HTTP request.
    - PUSH   : PUSH HTTP request.
    - PUT    : PUT HTTP request.
    - GET    : GET HTTP request.
    - DELETE : DELETE HTTP request.
    """

    POST = 'POST'
    """Use this to set the HTPP request method to POST."""
    PUSH = 'PUSH'
    """Use this to set the HTPP request method to PUSH."""
    PUT  = 'PUT'
    """Use this to set the HTPP request method to PUT."""
    GET = 'GET'
    """Use this to set the HTPP request method to GET."""
    DELETE = 'DELETE'
    """Use this to set the HTPP request method to DELETE."""
    PATCH = 'PATCH'
    """Use this to set the HTPP request method to PATCH."""

class API_EXECUTION_STATUS():
    """
    Enumeration representing the API execution status.

    Defined in:
    - APICaller.py

    Members:
    - AUTHENTICATION_ERROR : Authentication error occurred
    - UNKNOWN_ERROR        : Unknown error
    - SERVER_ERROR         : Server Error occurred
    - NONE                 : Default Status 
    - OK                   : API request executed successfuly
    """
    AUTHENTICATION_ERROR = 0
    """
    \tThis indicates that an authentication or access error occured 
    """
    UNKNOWN_ERROR        = 1
    """
    \tThis indicates that an unknown error occured 
    """
    SERVER_ERROR         = 2
    """
    \tThis indicates that a server error occured 
    """
    NONE                 = 3
    """
    \tThis is the default value for the API execution status if this value is returned it means that the API command has not been launched
    """
    OK                   = 4
    """
    \tThis indicates that the API request has been executed sucessfully
    """

class _API_HTTP_CODE_START():
    """
    Enumeration representing the start value for the HTTP return code.

    Defined in:
    - APICaller.py

    Members:
    - SUCCESS       : start value for HTTP Success
    - ACCESS_DENIED : start value for HTTP Access Denied
    - SERVER_ERROR  : start value for HTTP Server Error
    """
    SUCCESS = 200
    """
    \tThis is the start value returned by the server if the request is successful \n
    """
    ACCESS_DENIED = 400
    """
    \tThis is the start value returned by the server if the request fails because of an authentication error \n
    """
    SERVER_ERROR = 500
    """
    \tThis is the start value returned by the server if the request fails because of a server error \n
    """
    
class _API_HTTP_CODE_END():
    """
    Enumeration representing the end value for the HTTP return code.

    Defined in:
    - APICaller.py

    Members:
    - SUCCESS       : end value for HTTP Success\n
    - ACCESS_DENIED : end value for HTTP Access Denied\n
    - SERVER_ERROR  : end value for HTTP Server Error"""
    SUCCESS = 299
    """
    \tThis is the end value returned by the server if the request is successful \n
    """
    ACCESS_DENIED = 499
    """
    \tThis is the end value returned by the server if the request fails because of an authentication error \n
    """
    SERVER_ERROR = 599
    """
    \tThis is the end value returned by the server if the request fails because of a server error \n
    """

class _API_CALL_TYPE():
    """
    Enumeration representing the possible values for the field callType in the json file that the APICall object will read.
    
    Defined in: 
    - APICaller.py

    Members:
    - SIMPLE_CALL : API call is simple there is no modification to be done on the URL provided
    """
    SIMPLE_CALL = "simpleCall"
    """ Value to set the API call type to simpleCall"""

class _API_RESULT_TYPE():
    """
    Enumeration representing the possible values for the field resultType in the json file that the APICall object will read.
    
    Defined in: 
    - APICaller.py

    Members:
    - LIST : API call returns a list of items 
    """
    LIST = "list"
    """ Value to set the API result type to list of items"""
    DICTIONARY = "dict"
    """ Value to set the API result type to dictionary of items"""
    
class _API_CALL_AUTHENTICATION_METHOD():
    """
    Enumeration representing the possible values for the field APIAuthenticationMethod in the json file that the APICall object will read.
    
    Defined in: 
    - APICaller.py

    Members:
    - USING_API_KEY                   : API authentication method uses an API Key 
    - USING_USER_PASSWORD             : API authentication method uses a user and password pair
    - USING_NO_AUTHENTICATION         : API authentication method uses no authentication (very secure isn't it ?)
    - USING_API_KEY_AND_USER_PASSWORD : API authentication method uses both API Key and user/password pair
    """
    USING_API_KEY                   = "API"
    """ Value to set the API authentication method to API Key """
    USING_USER_PASSWORD             = "user/password"
    """ Value to set the API authentication method to user and password pair"""
    USING_NO_AUTHENTICATION         = "none"
    """ Value to set the API authentication method to no authentication (very secure isn't it ?) """
    USING_API_KEY_AND_USER_PASSWORD = "both"
    """ Value to set the API authentication method to both API Key and user/password pair"""

class _JSON_API_CALL_KEYS():
    """
    Enumeration representing all the fields in the json file that the APICall object will read.
    
    Defined in: 
    - APICaller.py

    Members:
    - FOR_TOP_LEVEL             : JSON File field "listOfAPICalls" is the top level field that contains all the API calls to execute.
    - FOR_DETAILS               : JSON File field "APIDetails" contains all the API calls details (url, method, type ...)
    - FOR_URL                   : JSON File field "url" contains the url of the API it must contain also the base url 
    - FOR_METHOD                : JSON File field "method" contains the API method (GET, PUT ... )
    - FOR_CALL_TYPE             : JSON File field "callType" contains the type of the call (check class _API_CALL_TYPE for all possible call types)
    - FOR_RESULT_TYPE           : JSON File field "resultType" contains the type of the returned data used byt API Call (check class _API_RESULT_TYPE for all possible result types)
    - FOR_HEADERS               : JSON File field "headers" contains the header parameters to include in the API call
    - FOR_FIELDS_TO_MANIPULATE  : JSON File field "fieldsToManipulate" contains the list of the result data to store for future use
    - FOR_HOST_FQDN             : JSON File field "hostFQDN" contains the host FQDN or IP address
    - FOR_AUTHENTICATION_METHOD : JSON File field "APIAuthenticationMethod" contains the API authentication method to use (check class _API_CALL_AUTHENTICATION_METHOD for possible values)
    - FOR_API_KEY_NAME          : JSON File field "APIKeyName" contains the header parameter name to use when using API Key authentication
    - FOR_API_KEY_VALUE         : JSON File field "APIKeyValue" contains the header parameter value to use when using API Key authentication
    - FOR_MIME_TYPE             : JSON File field "APIMimeType" contains the mime type value
    - FOR_RESULT_KEY            : JSON File field "resultKey" contains the result key for faster search in the results dictionary
    """

    FOR_TOP_LEVEL             = "listOfAPICalls"
    """ Defines the JSON top level element that contains all the API calls to execute. """
    FOR_DETAILS               = "APIDetails"
    """ Defines the JSON element that contains all the API calls details (url, method, type ...) """
    FOR_URL                   = "url"
    """ Defines the JSON element that contains the url of the API it must contain also the base url  """
    FOR_METHOD                = "method"
    """ Defines the JSON element that contains the API method (GET, PUT ... ) """
    FOR_CALL_TYPE             = "callType"
    """ Defines the JSON element that contains the type of the call (check class _API_CALL_TYPE for all possible call types) """
    FOR_RESULT_TYPE           = "resultType"
    """ Defines the JSON element that contains the type of the returned data used byt API Call (check class _API_RESULT_TYPE for all possible result types) """
    FOR_HEADERS               = "headers"
    """ Defines the JSON element that contains the header parameters to include in the API call """
    FOR_FIELDS_TO_MANIPULATE  = "fieldsToManipulate"
    """ Defines the JSON element that contains the list of the result data to store for future use """
    FOR_HOST_FQDN             = "hostFQDN"
    """ Defines the JSON element that contains the host FQDN or IP address """
    FOR_AUTHENTICATION_METHOD = "APIAuthenticationMethod"
    """ Defines the JSON element that contains the API authentication method to use (check class _API_CALL_AUTHENTICATION_METHOD for possible values) """
    FOR_API_KEY_NAME          = "APIKeyName"
    """ Defines the JSON element that contains the header parameter name to use when using API Key authentication """
    FOR_API_KEY_VALUE         = "APIKeyValue"
    """ Defines the JSON element that contains the header parameter value to use when using API Key authentication """
    FOR_MIME_TYPE             = "APIMimeType" 
    """ Defines the Mime type for the request """
    FOR_RESULT_KEY            = "resultKey"
    """ Defines the JSON element that contains the key to access the result of an specific API call """
    

DEFAULT_BEARER_KEY   = "Authorization"
DEFAULT_BEARER_VALUE = "Bearer "

_DEFAULT_API_METHOD = API_METHOD.GET
"""
Description : \n
\tThis is the default value for the API Method it is set to GET.\n
"""
_EMPTY_BODY_CONTENT = ""
_LOGFILE_PREFIX     = "APICall_"


class APICall(Debugging):
    def __init__(self, api_method = _DEFAULT_API_METHOD, path_for_log_file= DEFAULT_PATH_FOR_LOGFILE,debug_activation=DEFAULT_DEBUGGING_STATE, debug_type=DEFAULT_DEBUGGING_TYPE):
        """
        The `APICall` class provides a simple interface to prepare and execute API Calls.
        
        Parameters:
            - api_method      (str) : The api method to execute. Defaults to GET_API_METHOD
            - pathForLogFile  (str) : The path for the log file. Defaults to _DEFAULT_PATH_FOR_LOGFILE.
            - debugActivation (bool): The activation state of debugging. Defaults to DEFAULT_DEBUGGING_STATE.
            - debugType       (int) : The type of debugging. Defaults to DEFAULT_DEBUGGING_TYPE.

        Examples:
            - Single API call : \n
            \tapi = APICall(debug_activation=True)\n
            \tapi_execution_successfull = api.executeFromFile("myJsonFile.json")\n
            \tif api_execution_successfull:\n
            \t    result = api.readResult()/n
            \t    api.logThis("API Call result ",result)\n

            - Multiple API calls : \n
            \tapi = APICall(debug_activation=True)\n
            \tapi_execution_successfull = api.executeFromFile("myJsonFile.json")\n
            \tif api_execution_successfull:\n
            \t    result = api.readResult()/n
            \t    api.logThis("API Call result ",result)\n
        """

        super().__init__(_LOGFILE_PREFIX, path_for_log_file, debug_activation, debug_type)
        self.beginMethodSeparator("API Caller Object creation")
        self.__execution_status_code = API_EXECUTION_STATUS.NONE
        """Contains the result of the API execution """
        self.__url                   = IGNORE_THIS
        """Contains the url of the API execution """
        self.__mime_format           = MIME_FORMAT.JSON
        """Contains the mime format of the API request sst by default to JSON"""
        self.__API_data_result        = None
        """Contains the data returned by the API request"""
        self.__data_available        = False
        """If set to true then the API was excuted correctly and the __API_data_result contains the result"""
        self.__API_method            = api_method
        """Contains the API method to execute """
        self._HTTPS_connection        = None
        """This attribute is used to execute the API request """
        self._headers                = {}
        """This is the headers """
        self._api_responses : dict   = None
        """This is the list of all the API results when executing multiple requests"""
        self.__body_content = IGNORE_THIS
        """This contains the body content for the API request """
        self.__SSL_context           = None
        self._create_SSL_context()

    def _create_SSL_context(self):
        self.__SSL_context                = ssl.create_default_context()
        self.__SSL_context.check_hostname = False
        self.__SSL_context.verify_mode    = ssl.CERT_NONE
    
    def _getValueForKeyInDictionary(self, key, dictionary : dict):
        """
          Get the value for a key in a dictionary of a JSON File.

        Args:
            - key : The key for the value in the dictionary
            - dictionary : the dictionary from which the value has to be read 

        Returns:
            Return the value in the dictionary if it exists otherwise it returns false.
        """

        if (isinstance(dictionary,dict)):
            return dictionary[key] if (key in dictionary) else False
        else:
            return False

    def _clearHeaders(self):
        """
          Clears all the headers feilds.
          
        Returns:
            Nothing
        """
        self._headers = {}

    def _convertResultFromJSON(self, indent_value = 1):
        """
          Convert the API result from JSON format.
          
        Args:
            - indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the converted data if it is valid it returns false.
        """

        self.beginMethodSeparator("Read JSON File content",tabs = indent_value)
        indent_value += 1
        result = False
        
        # Check if the API executed successfully and if the data is available.
        if (self.__execution_status_code == API_EXECUTION_STATUS.OK):
            if (self.__data_available):
                self.logThis("Converting request result ", tabs= indent_value)
                try:
                    result = json.loads(self.__API_data_result)
                except  json.JSONDecodeError as theError:
                    self.logThis("Erro while converting ", theError, indent_value + 1)
                    result = False
                finally:
                    indent_value -= 1
                    self.endMethodSeparator(indent_value)
                    return result

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def _readJSONFile(self, JSON_file_name : str = IGNORE_THIS, indent_value = 1):
        """
          Reads the content of a JSON File where the API calls are defined.

        Args:
            - JSON_file_name (str, optional): The name of the JSON file to read. Defaults to IGNORE_THIS
            - indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the content of the JON File if it is valid otherwise it returns false.
        """
        self.beginMethodSeparator("Read JSON File content",tabs = indent_value)
        indent_value += 1
        result = False
        
        self.logThis("Reading the content of the following JSON File", JSON_file_name, indent_value)

        if not (JSON_file_name == IGNORE_THIS): 
            if not os.path.isfile(JSON_file_name):
                self.logThis("File doesn't exists !", tabs= indent_value + 1)
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return result
            try:
                self.logThis("File exists, start reading ...", tabs= indent_value + 1)
                with open(JSON_file_name) as api_call_file:
                    result = json.load(api_call_file)
                    self.logThis("Reading OK ",tabs= indent_value + 1)

            except ValueError as e:
                self.logThis("File does not contain valid JSON data", tabs= indent_value + 1)
                indent_value -= 1
                self.endMethodSeparator(indent_value)
                return result
        else:
            self.logThis("No File name provided to the method check your code !", tabs= indent_value + 1)
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return result
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def setAPIBodyContent(self, content : str = IGNORE_THIS, indent_value = 1):
        """
          Set the API request body.

        Args:
            - content (str): The API request body content in a string format.
            - indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Always returns true.
        """
        self.beginMethodSeparator("setAPIBodyContent",indent_value)
        indent_value += 1
        result = True
        if content == IGNORE_THIS:
            self.logThis("Emptying API Body content string",content, indent_value)
            self.__body_content = ''

        elif isinstance(content, str):
            self.logThis("Setting API Body content string",content, indent_value)
            self.__body_content = content
        else:
            self.logThis("Setting API Body content dict",content, indent_value)
            self.__body_content = json.dumps(content)

        # self.__body_content = urlencode(content)   =========> Suppressed as it throws an exception
        # self.__body_content = urlencode(content)
        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def setAPIUrl(self, url : str, indent_value = 1):
        """
        Set the API request URL.

        Parameters:
            - url (str): The API request target URL in a string format.
            - indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Always returns true.
        """
        self.beginMethodSeparator("setAPIUrl",indent_value)
        indent_value += 1
        result = True
        
        self.logThis("Setting API URL to",url, indent_value)
        self.__url = url
        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def setAPIMimeFormat(self, format : MIME_FORMAT = MIME_FORMAT.JSON, indent_value = 1):
        """
        Set the API MIME format.

        Args:
            - format (MIME_FORMAT, optional): The API mime format in a MIME_FORMAT class format. Defaults to JSON.
            - indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Always returns true.
        """
        self.beginMethodSeparator("setAPIMimeFormat",indent_value)
        indent_value += 1
        result = True
        
        self.logThis("Setting API Mime format to",format, indent_value)
        self.__mime_format = format
        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def setAPIMethod(self, method : API_METHOD, indent_value = 1):
        """
        Set the API method (GET, PUT ...).

        Args:
            - method (API_METHOD): The API method to call API_METHOD class format. 
            - indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Always returns true.
        """
        self.beginMethodSeparator("setAPIMethod",indent_value)
        indent_value += 1
        result = True
        
        self._clearHeaders()
        self.logThis("Setting API method to",method, indent_value)
        self.__API_method = method
        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def addHeaderParameter(self,header_parameter_key : str = IGNORE_THIS, header_parameter_value = None, indent_value = 1):
        """
        Add a header parameter to the API request.

        Args:
            - header_parameter_key (str)       : The header parameter key as string. If none provided set to IGNORE_THIS. 
            - header_parameter_value (any type): The header parameter value it can be of any type. If none provided set to None. 
            - indent_value (int, optional)      : Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Returns true if the header parameter was added, False otherwise.
        """
        self.beginMethodSeparator("addHeaderParameter",indent_value)
        indent_value += 1
        result = False
        self.logThis("Checking parameters", tabs= indent_value)
        if (header_parameter_key == IGNORE_THIS):
            self.logThis("Header Key not defined", tabs= indent_value + 1)
        elif (header_parameter_value == None):
            self.logThis("Header value not defined", tabs= indent_value + 1)
        else:
            self.logThis(f"Adding {header_parameter_key} => {header_parameter_value}", tabs= indent_value + 1)
            self._headers[header_parameter_key] = header_parameter_value
            result = True

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def addMultipleHeaderParameter(self, headerSource  = None , indent_value = 1):
        """
        Add a multiple header parameters to the API request.

        Args:
            - headerSource (any type)     : The header parameter source can be a list or a dictionary of header parameter values. If none provided set to None. 
            - indent_value (int, optional) : Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Returns true if at least one header parameter was added, False otherwise.
        """
        self.beginMethodSeparator("addMultipleHeaderParameter",indent_value)
        indent_value += 1
        result = False
        if headerSource != None: 
            if isinstance(headerSource, (list)):
                self.logThis("Adding header parameters from table",parameter_value=headerSource, tabs= indent_value + 1)
                for currentHeaderParameter in headerSource:
                    self.logThis("Processing header parameter",parameter_value=currentHeaderParameter, tabs= indent_value + 2)
                    if isinstance(currentHeaderParameter, (list)):
                        self.addHeaderParameter(currentHeaderParameter[0], currentHeaderParameter[1], indent_value + 1)
                        result = True
                    elif isinstance(currentHeaderParameter, (dict)):
                        key = next(iter(currentHeaderParameter))
                        self.addHeaderParameter(key, currentHeaderParameter[key], indent_value + 1)
                        result = True
                    else: 
                        self.logThis("Current Header paramaters has a wrong format " + str(headerSource.__class__) + " skiping this one", tabs= indent_value)

            elif isinstance(headerSource, (dict)):
                self.logThis("Adding header parameters from dictionary",parameter_value=headerSource, tabs= indent_value + 1)
                for currentHeaderKey in headerSource:
                    self.logThis("Processing header parameter for key",parameter_value=currentHeaderKey, tabs= indent_value + 2)
                    if (isinstance(headerSource[currentHeaderKey], (list)) or isinstance(headerSource[currentHeaderKey], (dict))):
                        self.logThis("Current Header paramaters has a wrong format " + str(headerSource.__class__) + " skiping this one", tabs= indent_value)
                    else:
                        self.addHeaderParameter(currentHeaderKey, headerSource[currentHeaderKey], indent_value + 1)
                        result = True
            else:
                self.logThis("Header source provided has a wrong format " + str(headerSource.__class__) + " skiping additional header addition", tabs= indent_value + 1)
        
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def prepareHTTPSConnection(self, host_FQDN, connection_port=IGNORE_THIS,indent_value = 1):
        """
        Prepares the HTTP connection for the API request.

        Args:
            - host_FQDN (str) : this is the host FQDN to which the API request will be sent.
            - indent_value (int, optional) : Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Returns always true. 
        """        
        self.beginMethodSeparator("prepareHTTPSConnection",indent_value)
        indent_value += 1
        result = True

        self.logThis("Creating the connection to ", host_FQDN, indent_value)
        if connection_port != IGNORE_THIS:
            self._HTTPS_connection  = http.client.HTTPSConnection(host_FQDN,port=connection_port,context=self.__SSL_context)
        else:
            self._HTTPS_connection  = http.client.HTTPSConnection(host_FQDN,context=self.__SSL_context)

        if self.__body_content == IGNORE_THIS:
            self.__body_content = _EMPTY_BODY_CONTENT

        # self.addHeaderParameter('Accept',self.__mime_format)

        self.logThis("API Request parameters ", parameter_value = " " ,                    tabs= indent_value)
        self.logThis("Method      ",            parameter_value = self.__API_method, tabs= indent_value + 1)
        self.logThis("URL         ",            parameter_value = self.__url,              tabs= indent_value + 1)
        self.logThis("Mime Format ",            parameter_value = self.__mime_format,      tabs= indent_value + 1)
        self.logThis("Header      ",            parameter_value = self._headers,           tabs= indent_value + 1)
        self.logThis("Content     ",            parameter_value = self.__body_content,     tabs= indent_value + 1)

        if len(self.__body_content) == 0 and len(self._headers) == 0:
            self.logThis("Empty Call",  tabs= indent_value + 2)
            self._HTTPS_connection.request(self.__API_method, self.__url)
        if len(self.__body_content) >  0 and len(self._headers) == 0:
            self.logThis("Simple Call with body content",  tabs= indent_value + 2)
            self._HTTPS_connection.request(self.__API_method, self.__url, body=self.__body_content)
        if len(self.__body_content) == 0 and len(self._headers) >  0:
            self.logThis("Simple Call with header only",  tabs= indent_value + 2)
            self._HTTPS_connection.request(self.__API_method, self.__url, headers=self._headers)
        if len(self.__body_content) >  0 and len(self._headers) >  0:
            self.logThis("Full Call with body and header content",  tabs= indent_value + 2)
            self._HTTPS_connection.request(self.__API_method, self.__url, body=self.__body_content, headers=self._headers)


        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def execute(self, indent_value = 1):
        """
        Executes the API request with the current parameters.

        Args:
            - indent_value (int, optional) : Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Returns true if the execution succeed otherwise it returns false. 
        """        
        self.beginMethodSeparator("execute",tabs = indent_value)
        indent_value += 1
        result = False
        
        try:
            self.logThis("Executing API Request", tabs= indent_value)
            response = self._HTTPS_connection.getresponse()
        except Exception as errorDescription:
            self.logThis("API execution error", errorDescription, tabs= indent_value + 1)
            self.__execution_status_code = API_EXECUTION_STATUS.UNKNOWN_ERROR
        else:
            if (_API_HTTP_CODE_START.SUCCESS <= response.status <= _API_HTTP_CODE_END.SUCCESS):
                self.logThis("API executed successfuly HTTP code ", response.status, tabs= indent_value + 1)
                self.__execution_status_code = API_EXECUTION_STATUS.OK
                self.__data_available        = True
                self.__API_data_result       = response.read()
                self.__API_data_result       = self.__API_data_result.decode()
                result = True
            elif (_API_HTTP_CODE_START.ACCESS_DENIED <= response.status <= _API_HTTP_CODE_END.ACCESS_DENIED):
                self.__API_data_result       = response.read()
                self.__API_data_result       = self.__API_data_result.decode()
                self.logThis("Access Denied error, server responded with HTTP code ", response.status, tabs= indent_value + 1)
                self.logThis("Description ", self.__API_data_result, tabs= indent_value + 1)
                self.logThis("End of error ",tabs= indent_value + 1)
                self.__execution_status_code = API_EXECUTION_STATUS.AUTHENTICATION_ERROR
                self.__data_available        = False
            elif (_API_HTTP_CODE_START.SERVER_ERROR <= response.status <= _API_HTTP_CODE_END.SERVER_ERROR):
                self.__API_data_result       = response.read()
                self.__API_data_result       = self.__API_data_result.decode()
                self.logThis("internal server error, server responded with HTTP code ", response.status, tabs= indent_value + 1)
                self.logThis("Description ", self.__API_data_result, tabs= indent_value + 1)
                self.logThis("End of error ",tabs= indent_value + 1)
                self.__execution_status_code = API_EXECUTION_STATUS.SERVER_ERROR
                self.__data_available        = False
            else:
                self.logThis("Unknown HTTP code returned, server responded with HTTP code ", response.status, tabs= indent_value + 1)
                temp = response.getheader("Location")

                self.logThis("Response is ", temp, tabs= indent_value + 2)


                for redirect in response.getheader("Location"):
                    print(f"Redirected to: {redirect.url}")
            
                self.__execution_status_code = API_EXECUTION_STATUS.UNKNOWN_ERROR
                self.__data_available        = False
        finally:
            indent_value -= 1
            self.endMethodSeparator(indent_value)
            return result                   

    def executeFromFile(self, fqdn = IGNORE_THIS, JSON_file_name : str = IGNORE_THIS, indent_value = 1):
        """
        Executes one or multiple API calls that are specified in a JSON file.

        Parameters:
            - fqdn (str, optional) : specify the fqdn or the IP address of the host to run the API call.
            - JSON_file_name (str, optional) : The JSON file name if not provided it is set to be ignored and the method will do nothing.
            - indent_value (int, optional)    : Indentation level for debugging purposes. Defaults to 1.

        Examples: 
            JSON file should have the following structure :
                {
                    "listOfAPICalls" : [
                        {
                            "APIDetails" : {
                                "resultKey"               : "put here the API call name for faster search",   \n
                                "url"                     : "put here the URL of the API ",                   \n
                                "hostFQDN"                : "put here the server FQDN or IP address",         \n
                                "APIAuthenticationMethod" : "put here the authentication method for the API", \n
                                "APIKeyName"              : "put here the API key name used in the header",   \n
                                "APIKeyValue"             : "put here the API key value",                     \n
                                "method"                  : "put here the API HTTP method",                   \n
                                "callType"                : "put here the call type",                         \n
                                "resultType"              : "put here the the expected result type",          \n
                                "headers" : [
                                    {
                                        "insert here" : "as many header parameter as required by the API" :   \n
                                    }
                                ]
                            },
                            "fieldsToManipulate" : [
                                "insert here",              \n
                                "all the need fields name", \n
                                "returned by the API",      \n
                                "that you wish to store",   \n
                                "and access "               \n
                            ]
                        }
                    ]
                }

        Returns:
            Returns true if at least one of the API calls in the JSON file succeed otherwise it returns false. 
        """        
        self.beginMethodSeparator("execute API calls from a JSON File",tabs = indent_value)
        indent_value += 1
        result = False
        
        self.logThis("Executing API Request using the following JSON File", JSON_file_name, indent_value)

        api_call_data = self._readJSONFile(JSON_file_name,indent_value + 1)
        current_api_call_index = 0
        # check if there is any data in the JSON file
        if api_call_data:
            # reading the top level value of the JSON file that contains the list of API calls to execute
            list_of_calls = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_TOP_LEVEL,api_call_data)
            self.logThis("Reading the top level element of the JSON file and checking if is a valid list of API Calls", list_of_calls, indent_value)
            # check if the list is valid
            if (list_of_calls and (isinstance(list_of_calls,list))):
                # initialize the list of calls responses 
                self._api_responses = {}
                for current_api_call in list_of_calls:
                    # reading all the call details
                    # self._api_responses.append([])    # Commented on Jan. 25th 2024 
                    self.logThis("Reading the call details ", tabs= indent_value + 1)
                    call_details = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_DETAILS,current_api_call)
                    # check if call details are defined for current call
                    if call_details:
                        url                       = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_URL                  , call_details)
                        host_name                 = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_HOST_FQDN            , call_details)
                        method                    = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_METHOD               , call_details)
                        call_type                 = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_CALL_TYPE            , call_details)
                        result_type               = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_RESULT_TYPE          , call_details)
                        api_authentication_method = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_AUTHENTICATION_METHOD, call_details)
                        api_key_name_for_results  = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_RESULT_KEY           , call_details)
                        # headers is not a mandatory parameter
                        headers                   = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_HEADERS              , call_details)
                        if headers:
                            headers = json.loads(headers)
                        # check if all elements are valid
                        if not host_name:
                            host_name = fqdn
                        if (url and host_name and method and call_type and result_type and api_authentication_method):
                            match api_authentication_method:
                                case _API_CALL_AUTHENTICATION_METHOD.USING_API_KEY:
                                    self.logThis("Processing a request using API Key ", tabs= indent_value + 2)
                                    API_key_name  = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_API_KEY_NAME , call_details)
                                    API_key_value = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_API_KEY_VALUE, call_details)
                                    API_url_to_call = "https://" + host_name + url

                                    # self.logThis("API_url_to_call",API_url_to_call, tabs= indent_value + 2)
                                    # API_url_to_call = urlencode(API_url_to_call)
                                    # self.logThis("API_url_to_call",API_url_to_call, tabs= indent_value + 2)

                                    self.logThis("Preparing the API request", tabs= indent_value + 2)
                                    self.setAPIUrl(API_url_to_call, indent_value + 3)
                                    self._clearHeaders()
                                    self.setAPIMethod(getattr(API_METHOD, method))
                                    self.addHeaderParameter(API_key_name,API_key_value, indent_value + 3)
                                    self.addMultipleHeaderParameter(headers, indent_value + 3)
                                    self.prepareHTTPSConnection(host_name, indent_value + 3)
                                    # self.dump(3)
                                    self.logThis("Executing ...", tabs= indent_value + 2)
                                    self.execute(indent_value + 3)

                                    if not((self.__execution_status_code == API_EXECUTION_STATUS.OK) and (self.__data_available)):
                                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)      # Commented on Jan. 25th 2024
                                        self._api_responses[api_key_name_for_results] = IGNORE_THIS
                                        self.logThis("Request execution failed ...", tabs= indent_value + 3)
                                    else:
                                        self.logThis("Request execution Succeed ...", tabs= indent_value + 3)
                                        # reading all the fields to store for current call
                                        self.logThis("Getting the list of all fields to read ...", tabs= indent_value + 3)
                                        list_of_fields_to_read = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_FIELDS_TO_MANIPULATE, current_api_call)
                                        if list_of_fields_to_read:
                                            # Convert the list of fields from JSON format 
                                            result_data_in_JSON = self._convertResultFromJSON(indent_value + 3)
                                            # Checking if we have a valid list of fields
                                            self.logThis("Checking if we have a valid list of fields ...", tabs= indent_value + 4)
                                            match result_type:
                                                case _API_RESULT_TYPE.LIST:
                                                    if (isinstance(result_data_in_JSON,list)):
                                                        # Reading all element returned by the API call
                                                        for current_element in result_data_in_JSON:
                                                            result_to_store = {}
                                                            # For all element returned check if the it contains any of the fields
                                                            # if it doesn't then the value for the field is set to IGNORE_THIS 
                                                            for current_field in list_of_fields_to_read:
                                                                valueFound = self._getValueForKeyInDictionary(current_field, current_element)
                                                                if not valueFound:
                                                                    valueFound = IGNORE_THIS
                                                                self.logThis(f"Setting value for field {current_field} => {valueFound}", tabs= indent_value + 5)
                                                                result_to_store[current_field] = valueFound                                                        
                                                                # if (current_field in current_element):
                                                                #     result_to_store[current_field] = current_element[current_field]
                                                                #     self.logThis(f"Found value for field {current_field} => {current_element[current_field]}", tabs=3)
                                                            # self._api_responses[current_api_call_index].append(result_to_store)        # Commented on Jan. 25th 2024
                                                            self._api_responses[api_key_name_for_results] = result_to_store
                                                            result = True
                                                    else:
                                                        self.logThis("Unvalid list of fields ...", tabs= indent_value + 4)
                                                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                                        self._api_responses[api_key_name_for_results] = IGNORE_THIS
                                                case _API_RESULT_TYPE.DICTIONARY:
                                                    if (isinstance(result_data_in_JSON,dict)):
                                                        # Reading all element returned by the API call
                                                        # for current_element in result_data_in_JSON:
                                                            result_to_store = {}
                                                            # For all element returned check if the it contains any of the fields
                                                            # if it doesn't then the value for the field is set to IGNORE_THIS 
                                                            for current_field in list_of_fields_to_read:
                                                                valueFound = self._getValueForKeyInDictionary(current_field, result_data_in_JSON)
                                                                if not valueFound:
                                                                    valueFound = IGNORE_THIS
                                                                self.logThis(f"Setting value for field {current_field} => {valueFound}", tabs= indent_value + 5)
                                                                result_to_store[current_field] = valueFound                                                        
                                                                # if (current_field in current_element):
                                                                #     result_to_store[current_field] = current_element[current_field]
                                                                #     self.logThis(f"Found value for field {current_field} => {current_element[current_field]}", tabs=3)
                                                            # self._api_responses[current_api_call_index].append(result_to_store)        # Commented on Jan. 25th 2024
                                                            self._api_responses[api_key_name_for_results] = result_to_store
                                                            result = True
                                                    else:
                                                        self.logThis("Unvalid dictionary of fields ...", tabs= indent_value + 4)
                                                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)        # Commented on Jan. 25th 2024
                                                        self._api_responses[api_key_name_for_results] = result_to_store
                                                case _:
                                                    self.logThis("Undefined result type ...", tabs= indent_value + 3)
                                                    # self._api_responses[current_api_call_index].append(IGNORE_THIS)            # Commented on Jan. 25th 2024
                                                    self._api_responses[api_key_name_for_results] = IGNORE_THIS

                                        else:
                                            self.logThis("List of fields to store is not valid skipping  ...", tabs= indent_value + 3)
                                            # self._api_responses[current_api_call_index].append(IGNORE_THIS)                     # Commented on Jan. 25th 2024
                                            self._api_responses[api_key_name_for_results] = IGNORE_THIS
                                case _:
                                    self.logThis("Wrong API authentication method",api_authentication_method,tabs= indent_value + 2)
                                    # self._api_responses[current_api_call_index].append(IGNORE_THIS)                            # Commented on Jan. 25th 2024
                                    self._api_responses[api_key_name_for_results] = IGNORE_THIS
                    else:
                        self.logThis("Call details are not defined for current call", tabs= indent_value + 2)
                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)                                        # Commented on Jan. 25th 2024
                        self._api_responses[api_key_name_for_results] = IGNORE_THIS
                    current_api_call_index += 1       
            else:
                self.logThis("Top level element doesn't exists or do not contain a valid list of calls", tabs= indent_value + 1)
        else:
            self.logThis("No API Data to process", tabs= indent_value + 1)
            
        if result:
            self.__API_data_result = self._api_responses
            self.__data_available = True
        else:
            self.__API_data_result = IGNORE_THIS
            self.__data_available = False

        return result                   

    def executeFromFilewithOAuth(self, fqdn = IGNORE_THIS, bearer_token = IGNORE_THIS, JSON_file_name : str = IGNORE_THIS, indent_value = 1):
        """
        Executes one or multiple API calls that are specified in a JSON file and use the bearer as the authorization.

        Parameters:
            - fqdn (str, optional)            : specify the fqdn or the IP address of the host to run the API call.
            - bearer_token    (str, optional) : The bearer token to be used
            - JSON_file_name (str, optional)  : The JSON file name if not provided it is set to be ignored and the method will do nothing.
            - indent_value (int, optional)    : Indentation level for debugging purposes. Defaults to 1.

        Examples: 
            JSON file should have the following structure :
                {
                    "listOfAPICalls" : [
                        {
                            "APIDetails" : {
                                "resultKey"               : "put here the API call name for faster search",   \n
                                "url"                     : "put here the URL of the API ",                   \n
                                "hostFQDN"                : "put here the server FQDN or IP address",         \n
                                "APIAuthenticationMethod" : "put here the authentication method for the API", \n
                                "APIKeyName"              : "put here the API key name used in the header",   \n
                                "APIKeyValue"             : "put here the API key value",                     \n
                                "method"                  : "put here the API HTTP method",                   \n
                                "callType"                : "put here the call type",                         \n
                                "resultType"              : "put here the the expected result type",          \n
                                "headers" : [
                                    {
                                        "insert here" : "as many header parameter as required by the API" :   \n
                                    }
                                ]
                            },
                            "fieldsToManipulate" : [
                                "insert here",              \n
                                "all the need fields name", \n
                                "returned by the API",      \n
                                "that you wish to store",   \n
                                "and access "               \n
                            ]
                        }
                    ]
                }

        Returns:
            Returns true if at least one of the API calls in the JSON file succeed otherwise it returns false. 
        """        
        self.beginMethodSeparator("execute API calls from a JSON File and use oAuth",tabs = indent_value)
        indent_value += 1
        result = False
        
        self.logThis("Executing API Request using the following JSON File", JSON_file_name, indent_value)

        api_call_data = self._readJSONFile(JSON_file_name,indent_value + 1)
        current_api_call_index = 0
        # check if there is any data in the JSON file
        if api_call_data:
            # reading the top level value of the JSON file that contains the list of API calls to execute
            list_of_calls = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_TOP_LEVEL,api_call_data)
            self.logThis("Reading the top level element of the JSON file and checking if is a valid list of API Calls", list_of_calls, indent_value)
            # check if the list is valid
            if (list_of_calls and (isinstance(list_of_calls,list))):
                # initialize the list of calls responses 
                # self._api_responses = []            # Commented on Jan. 25th 2024
                self._api_responses = {}
                for current_api_call in list_of_calls:
                    # reading all the call details
                    # self._api_responses.append([])        # Commented on Jan. 25th 2024
                    self.logThis("Reading the call details ", tabs= indent_value + 1)
                    call_details = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_DETAILS,current_api_call)
                    # check if call details are defined for current call
                    if call_details:
                        url                       = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_URL                  , call_details)
                        host_name                 = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_HOST_FQDN            , call_details)
                        method                    = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_METHOD               , call_details)
                        call_type                 = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_CALL_TYPE            , call_details)
                        result_type               = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_RESULT_TYPE          , call_details)
                        api_authentication_method = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_AUTHENTICATION_METHOD, call_details)
                        mime_type                 = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_MIME_TYPE            , call_details)
                        api_key_name_for_results  = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_RESULT_KEY           , call_details)
                        
                        # headers is not a mandatory parameter
                        headers                   = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_HEADERS              , call_details)
                        if not host_name:
                            host_name = fqdn
                        
                        # check if all elements are valid
                        if (url and host_name and method and call_type and result_type and api_authentication_method):
                            match api_authentication_method:
                                case _API_CALL_AUTHENTICATION_METHOD.USING_API_KEY:
                                    self.logThis("Processing a request using API Key ", tabs= indent_value + 2)
                                    API_key_name  = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_API_KEY_NAME , call_details)
                                    API_key_value = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_API_KEY_VALUE, call_details) + bearer_token
                                    API_url_to_call = "https://" + host_name + url

                                    # self.logThis("API_url_to_call",API_url_to_call, tabs= indent_value + 2)
                                    # API_url_to_call = urlencode(API_url_to_call)
                                    # self.logThis("API_url_to_call",API_url_to_call, tabs= indent_value + 2)

                                    self.setAPIBodyContent(indent_value = indent_value + 2)
                                    self.logThis("Preparing the API request", tabs= indent_value + 2)
                                    if mime_type:
                                        mime_type = getattr(MIME_FORMAT, mime_type) 
                                        self.setAPIMimeFormat(mime_type, indent_value + 3)
                                    self.setAPIUrl(API_url_to_call, indent_value + 3)
                                    self._clearHeaders()
                                    self.setAPIMethod(getattr(API_METHOD, method))
                                    self.addHeaderParameter(API_key_name,API_key_value, indent_value + 3)
                                    self.addMultipleHeaderParameter(headers, indent_value + 3)
                                    self.prepareHTTPSConnection(host_name, indent_value + 3)
                                    # self.dump(3)
                                    self.logThis("Executing ...", tabs= indent_value + 2)
                                    self.execute(indent_value + 3)
                                    if not((self.__execution_status_code == API_EXECUTION_STATUS.OK) and (self.__data_available)):
                                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                        self._api_responses[api_key_name_for_results] = IGNORE_THIS

                                        self.logThis("Request execution failed ...", tabs= indent_value + 3)
                                    else:
                                        self.logThis("Request execution Succeed ...", tabs= indent_value + 3)
                                        # reading all the fields to store for current call
                                        self.logThis("Getting the list of all fields to read ...", tabs= indent_value + 3)
                                        list_of_fields_to_read = self._getValueForKeyInDictionary(_JSON_API_CALL_KEYS.FOR_FIELDS_TO_MANIPULATE, current_api_call)
                                        if list_of_fields_to_read:
                                            # Convert the list of fields from JSON format 
                                            result_data_in_JSON = self._convertResultFromJSON(indent_value + 3)
                                            # Checking if we have a valid list of fields
                                            self.logThis("Checking if we have a valid list of fields ...", tabs= indent_value + 4)
                                            match result_type:
                                                case _API_RESULT_TYPE.LIST:
                                                    if (isinstance(result_data_in_JSON,list)):
                                                        # Reading all element returned by the API call
                                                        for current_element in result_data_in_JSON:
                                                            result_to_store = {}
                                                            # For all element returned check if the it contains any of the fields
                                                            # if it doesn't then the value for the field is set to IGNORE_THIS 
                                                            for current_field in list_of_fields_to_read:
                                                                valueFound = self._getValueForKeyInDictionary(current_field, current_element)
                                                                if not valueFound:
                                                                    valueFound = IGNORE_THIS
                                                                self.logThis(f"Setting value for field {current_field} => {valueFound}", tabs= indent_value + 5)
                                                                result_to_store[current_field] = valueFound                                                        
                                                                # if (current_field in current_element):
                                                                #     result_to_store[current_field] = current_element[current_field]
                                                                #     self.logThis(f"Found value for field {current_field} => {current_element[current_field]}", tabs=3)
                                                            # self._api_responses[current_api_call_index].append(result_to_store)
                                                            self._api_responses[api_key_name_for_results] = result_to_store
                                                            
                                                            result = True
                                                    else:
                                                        self.logThis("Unvalid list of fields ...", tabs= indent_value + 4)
                                                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                                        self._api_responses[api_key_name_for_results] = IGNORE_THIS
                                                case _API_RESULT_TYPE.DICTIONARY:
                                                    if (isinstance(result_data_in_JSON,dict)):
                                                        # Reading all element returned by the API call
                                                        # for current_element in result_data_in_JSON:
                                                            result_to_store = {}
                                                            # For all element returned check if the it contains any of the fields
                                                            # if it doesn't then the value for the field is set to IGNORE_THIS 
                                                            for current_field in list_of_fields_to_read:
                                                                valueFound = self._getValueForKeyInDictionary(current_field, result_data_in_JSON)
                                                                if not valueFound:
                                                                    valueFound = IGNORE_THIS
                                                                self.logThis(f"Setting value for field {current_field} => {valueFound}", tabs= indent_value + 5)
                                                                result_to_store[current_field] = valueFound                                                        
                                                                # if (current_field in current_element):
                                                                #     result_to_store[current_field] = current_element[current_field]
                                                                #     self.logThis(f"Found value for field {current_field} => {current_element[current_field]}", tabs=3)
                                                            # self._api_responses[current_api_call_index].append(result_to_store)
                                                            self._api_responses[api_key_name_for_results] = result_to_store
                                                            result = True
                                                    else:
                                                        self.logThis("Unvalid dictionary of fields ...", tabs= indent_value + 4)
                                                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                                        self._api_responses[api_key_name_for_results] = IGNORE_THIS
                                                case _:
                                                    self.logThis("Undefined result type ...", tabs= indent_value + 3)
                                                    # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                                    self._api_responses[api_key_name_for_results] = IGNORE_THIS

                                        else:
                                            self.logThis("List of fields to store is not valid skipping  ...", tabs= indent_value + 3)
                                            # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                            self._api_responses[api_key_name_for_results] = IGNORE_THIS
                                case _:
                                    self.logThis("Wrong API authentication method",api_authentication_method,tabs= indent_value + 2)
                                    # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                                    self._api_responses[api_key_name_for_results] = IGNORE_THIS       
                    else:
                        self.logThis("Call details are not defined for current call", tabs= indent_value + 2)
                        # self._api_responses[current_api_call_index].append(IGNORE_THIS)
                        self._api_responses[api_key_name_for_results] = IGNORE_THIS  
                    current_api_call_index += 1
                    self.__execution_status_code = API_EXECUTION_STATUS.OK
                    self.__data_available = True

       
            else:
                self.logThis("Top level element doesn't exists or do not contain a valid list of calls", tabs= indent_value + 1)
        else:
            self.logThis("No API Data to process", tabs= indent_value + 1)
            
        if result:
            self.__API_data_result = self._api_responses
            self.__data_available = True
        else:
            self.__API_data_result = IGNORE_THIS
            self.__data_available = False

        return result    

    def readResult(self, indent_value = 1):
        """
          Reads the result of the API call.

        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the result of the API Call if the call was successful otherwise it returns false.
        """
        self.beginMethodSeparator("readResult",indent_value)
        indent_value += 1
        result = False
        
        if (self.__execution_status_code == API_EXECUTION_STATUS.OK):
            if (self.__data_available):
                result = self.__API_data_result

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def readResult(self, indent_value = 1):
        """
          Reads the result of the API call.

        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the result of the API Call if it was successful otherwise it returns false.
        """
        self.beginMethodSeparator("readResult",indent_value)
        indent_value += 1
        result = False
        
        if (self.__execution_status_code == API_EXECUTION_STATUS.OK):
            if (self.__data_available):
                result = self.__API_data_result 

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def readResults(self, indent_value = 1):
        """
          Reads the result of multiple API calls.

        Args:
            indent_value (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the result of all the API Calls if they were successful otherwise it returns false.
        """
        self.beginMethodSeparator("readResults",indent_value)
        indent_value += 1
        result = False
        
        if (self.__execution_status_code == API_EXECUTION_STATUS.OK):
            if (self.__data_available):
                result = self._api_responses

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def readResultsForKey(self, result_key_to_read = IGNORE_THIS, indent_value = 1):
        """
          Reads a specific result entry in the multiple API calls result dictionary.

        Args:
            result_key_to_read (str, optional) : The key to read in the multiple API calls result dictionary
            indent_value (int, optional)        : Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the specific result if it exists, otherwise it returns false.
        """
        self.beginMethodSeparator("readResults",indent_value)
        indent_value += 1
        result = False
        self.logThis("Checking Key", tabs= indent_value + 1)
        if not ((result_key_to_read == None) or (result_key_to_read == IGNORE_THIS)):
            self.logThis("Checking API Calls execution status", tabs= indent_value + 1)
            if (self.__execution_status_code == API_EXECUTION_STATUS.OK):
                self.logThis("Checking if API call data results are available", tabs= indent_value + 1)
                if (self.__data_available):
                    self.logThis("Reading result data for key",result_key_to_read, tabs= indent_value + 1)
                    result = self._getValueForKeyInDictionary(result_key_to_read,self._api_responses)
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    
    def getHTTPResponseCode(self, indent_value = 1):
        """
          Reads the HTTP response code returned by the API Call.
          
        Returns:
            Return the HTTP response code.
        """
        print("returning ",self.__execution_status_code,flush=True)
        return self.__execution_status_code

