"""
HPeSSE: A Simple Library for HPeSSE access
Author: David Guillet
Creation Date: Jan. 17 2025
Last Modified Date: Jun. 26 2025
Version: 1.0.2
Version History :
    1.0.0 : Initial release
    1.0.1 : Adding Applications and Tags API 
    1.0.2 : Modifying the __getAPIData to handle multiple pages in API call result
     
    
To Do :
    
    
"""

from modules.networkHost import *
from modules.APICaller   import *
from modules.file        import *
from datetime            import datetime

_REPLACEMENT_STRING = 'REPLACE_THIS'

_LOGFILE_PREFIX = "HpeSSE_"

_AUTHENTICATION_STRING = 'Bearer '

_DEFAULT_API_PORT = 443


DEFAULT_APPPLICATION_ENABLE_STATUS = True

_DEFAULT_CONNECTOR_ZONE_DESCRIPTION = " Automated Zone created :  "
_DEFAULT_TAG_DESCRIPTION            = " Automated Tag created :  "
_DEFAULT_PORTS_AND_PROTOCOLS        = ["1-65535"]

_DEFAULT_PAGE_SIZE   = 10
_DEFAULT_PAGE_NUMBER = 1


_HPE_SSE_API_GATEWAY = "admin-api.axissecurity.com"

class HPE_SSE_APPLICATION_TYPES():
    """
    Enumeration representing the possible ZTNA application types\n
    Defined in:
    - HPeSSE.py

    Members:
    
    """
    NETWORK_RANGE = "NetworkRange"
    """
    \tApplication is a Network Range"""  

class _API_CALLS():
    """
    Enumeration representing the API Calls to access HPe SSE platform.
    Defined in:
    - HPeSSE.py

    Members:
    """
    COMMIT = f"/api/v1/commit"
    """
    \tCommit all the changes""" 
    GET_CONNECTOR_ZONES = f"/api/v1/ConnectorZones?pageSize={_DEFAULT_PAGE_SIZE}&pageNumber={_DEFAULT_PAGE_NUMBER}"
    """
    \tGet the list of connector Zones""" 
    CREATE_CONNECTOR_ZONES = "/api/v1/ConnectorZones"
    """
    \tCreate a connector Zones""" 
    GET_CONNECTOR = f"/api/v1/connectors?pageSize={_DEFAULT_PAGE_SIZE}&pageNumber={_DEFAULT_PAGE_NUMBER}"
    """
    \tGet the list of connector"""
    CREATE_CONNECTOR = "/api/v1/connectors"
    """
    \tCreate a new connector"""

    GET_TAGS = f"/api/v1/tags?pageSize={_DEFAULT_PAGE_SIZE}&pageNumber={_DEFAULT_PAGE_NUMBER}"
    """
    \tGet the list of tags"""

    CREATE_TAG = f"/api/v1/tags"
    """
    \tCreate a new tag"""

    GET_APPLICATIONS = f"/api/v1/applications?pageSize={_DEFAULT_PAGE_SIZE}&pageNumber={_DEFAULT_PAGE_NUMBER}"
    """
    \tGet the list of Applications"""
    DELETE_APPLICATIONS = f"/api/v1/applications/"
    """
    \tDelete an applications. Must append the application ID at the end"""

    DUMP_APPLICATION = f"/api/v1/applications/"
    """
    \tDump an application. Must append the application ID at the end"""

    CREATE_APPLICATION = f"/api/v1/applications"
    """
    \tCreate an application."""

class HPeSSE(NetworkHost):

    def __init__(self, api_token, fqdn = _HPE_SSE_API_GATEWAY, api_tcp_port = _DEFAULT_API_PORT, path_for_log_file= DEFAULT_PATH_FOR_LOGFILE,debug_activation=DEFAULT_DEBUGGING_STATE, debug_type=DEFAULT_DEBUGGING_TYPE):
        """
        Initialize the proxmox object with the given parameters. 
        Args:
            api_token (str)                  : The API token to access the HPe SSE tenant informations 
            fqdn (str,optional)              : The FQDN of the HPe SSE API Gateway. 
            api_tcp_port (int,optionale      : TCP port used to connect to the host's APIs. Defaults to 8006
            path_for_log_file (str,optional) : The path for the log file. Defaults to DEFAULT_PATH_FOR_LOGFILE.
            debug_activation (bool,optional) : The activation state of debugging. Defaults to DEFAULT_DEBUGGING_STATE.
            debug_type (int,optional)        : The type of debugging. Defaults to DEFAULT_DEBUGGING_TYPE.
        """
        super().__init__(fqdn, username = IGNORE_THIS, password = IGNORE_THIS, tcp_port_to_test = api_tcp_port, log_file_name=_LOGFILE_PREFIX + str(fqdn), path_for_log_file= path_for_log_file,debug_activation=debug_activation, debug_type=debug_type)

        self.beginMethodSeparator("HPeSSE Host Object creation")
        self.__fqdn                       = fqdn 
        """ The name of the API gateway"""
        
        self.__authentication_string = _AUTHENTICATION_STRING + api_token #+ "}" + "\"" 
        """ The authentication string used for the API Calls."""
        self.__api_tcp_port               = api_tcp_port
        """ TCP port used for the API calls"""
        self.__connector_zones_list = {}
        """ Dictionary containing the list of Connector zones with theire internal ID """
        self.__connectors_list = {}
        """ Dictionary containing the list of Connectors with theire internal ID """
        self.__tags_list = {}
        """ Dictionary containing the list of Tags with theire internal ID """
        self.__applications_list = {}
        """ Dictionary containing the list of Applications with theire internal ID """
        self.__API_caller = APICall(path_for_log_file= path_for_log_file,debug_activation=debug_activation, debug_type=debug_type)
        """ APICall instance to execute API calls to the SSE platform """
            
    def dump(self, indent_value=1):
        super().dump(indent_value)
        self.logThis("Dumping Object",self, indent_value)

    def __setAPICaller(self,api_method : API_METHOD, api_url : _API_CALLS, indent_value = 1):
        """
          Prepares the API Caller for the next API call
           
        Args:
            api_method (API_METHOD): defines the API method (GET, POST ...)
            api_url    (_API_CALLS) : defines the API call to be executed 

            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return nothing
        """
        self.__API_caller.setAPIMethod(api_method)
        self.__API_caller.setAPIUrl(api_url)
        self.__API_caller.addHeaderParameter("Authorization",self.__authentication_string)

    def __getAPIData(self,indent_value = 1):
        """
          Reads the content of an API call to proxmox server, converts the JSON string to a data structure and returns it
           
        Args:
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the data structure.
        """
        number_of_pages = 0
        result = json.loads(self.__API_caller.readResult())
        self.logThis("Number of pages ",result, tabs= indent_value + 2)
        if ("totalPages" in result):
            number_of_pages = result["totalPages"]
        if ("data" in result):
            result = result["data"]
        self.logThis("Returning Number of pages " + str(number_of_pages) + "\n\t\tAnd result", result, tabs= indent_value + 2)
        return result, number_of_pages

    def commitChanges(self,indent_value = 1):
        """
          Commit all the pending changes.
           
        Args:
            indentValue        (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to commit the changes otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Commit",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            query_string =  _API_CALLS.COMMIT 
            self.__setAPICaller(API_METHOD.POST,query_string)
            # self.__API_caller.setAPIMimeFormat(IGNORE_THIS, indent_value + 1)
            self.__API_caller.setAPIBodyContent(indent_value= indent_value + 1)
            # self.__API_caller.addHeaderParameter("Content-Type","application/json")
            self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
            if self.__API_caller.execute():
                self.logThis("Commit done !", tabs = indent_value + 1)
            else:
                self.logThis("Commit failed !",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def loadConnectorZonesList(self, current_interation = 1, indent_value = 1):
        """
          Connects to the API gateway and retrieve the connector zones list.
           
        Args:
            current_interation (int, optional): provide the current iteration of the method call 
            indentValue        (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to populate the list of Connector zones otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("load Connector Zones",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            query_string =  _API_CALLS.GET_CONNECTOR_ZONES[:-1] + str(current_interation) 
            self.__setAPICaller(API_METHOD.GET,query_string)
            self.__API_caller.addHeaderParameter("Content-Type","application/json")
            self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
            if self.__API_caller.execute():
                list_of_connector_zones, number_of_interations  = self.__getAPIData()
                if current_interation == 1:
                    self.__connector_zones_list = {}
                # self.logThis("list_of_connector_zones", list_of_connector_zones, tabs = indent_value + 1)
                if len(list_of_connector_zones) > 0:
                    for current_zone in list_of_connector_zones:
                        self.logThis("Selecting", current_zone["name"] , tabs = indent_value + 1)
                        self.__connector_zones_list[current_zone["name"]] = current_zone["id"]
                        result = True
                else:
                    self.logThis("Received an empty list", tabs = indent_value + 1)
                #  Check if we need to perform other iterations
                self.logThis("Iteration " + str(current_interation) + "/" + str(number_of_interations), tabs = indent_value + 1)
                if current_interation < number_of_interations:
                    self.loadConnectorZonesList(current_interation + 1, indent_value + 1)

            else:
                self.logThis("Can't get the list of connector zones",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def loadConnectorList(self, current_interation = 1, indent_value = 1):
        """
          Connects to the API gateway and retrieve the connector list.
           
        Args:
            current_interation (int, optional): provide the current iteration of the method call 
            indentValue        (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to populate the list of Connector otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("load Connectors",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            query_string =  _API_CALLS.GET_CONNECTOR[:-1] + str(current_interation) 
            self.__setAPICaller(API_METHOD.GET,query_string)
            self.__API_caller.addHeaderParameter("Content-Type","application/json")
            self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
            if self.__API_caller.execute():
                list_of_connectors, number_of_interations = self.__getAPIData()
                if current_interation == 1:
                    self.__connectors_list = {}
                # self.logThis("list_of_connector_zones", list_of_connectors, tabs = indent_value + 1)
                if len(list_of_connectors) > 0:
                    for current_connector in list_of_connectors:
                        self.logThis("Selecting", current_connector["name"] , tabs = indent_value + 1)
                        self.__connectors_list[current_connector["name"]] = current_connector["id"]
                        result = True
                else:
                    self.logThis("Received an empty list", tabs = indent_value + 1)
                #  Check if we need to perform other iterations
                self.logThis("Iteration " + str(current_interation) + "/" + str(number_of_interations), tabs = indent_value + 1)
                if current_interation < number_of_interations:
                    self.loadConnectorList(current_interation + 1, indent_value + 1)

            else:
                self.logThis("Can't get the list of connectors",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def loadTagsList(self, current_interation = 1, indent_value = 1):
        """
          Connects to the API gateway and retrieve the list of configured Tags.
           
        Args:
            current_interation (int, optional): provide the current iteration of the call 
            indentValue        (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to populate the list of Tags otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("load Tags",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable searching for Tags list", tabs = indent_value)
            query_string =  _API_CALLS.GET_TAGS[:-1] + str(current_interation) 
            self.__setAPICaller(API_METHOD.GET,query_string)
            self.__API_caller.addHeaderParameter("Content-Type","application/json")

            self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
            if self.__API_caller.execute():
                list_of_tags, number_of_interations = self.__getAPIData()
                # self.logThis("list_of_tags", list_of_tags, tabs = indent_value + 1)
                # Initialize the internal tag list property
                if current_interation == 1:
                    self.__tags_list = {}
                #  Populate the tag list
                if len(list_of_tags) > 0:
                    for current_tag in list_of_tags:
                        self.logThis("Selecting", current_tag["name"] , tabs = indent_value + 1)
                        self.__tags_list[current_tag["name"]] = current_tag["id"]
                        result = True
                else:
                    self.logThis("Received an empty list", tabs = indent_value + 1)
                #  Check if we need to perform other iterations
                self.logThis("Iteration " + str(current_interation) + "/" + str(number_of_interations), tabs = indent_value + 1)
                if current_interation < number_of_interations:
                    self.loadTagsList(current_interation + 1, indent_value + 1)
            else:
                self.logThis("Can't get the list of Tags",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def loadApplicationList(self, current_interation = 1, indent_value = 1):
        """
          Connects to the API gateway and retrieve the list of configured Applications.
           
        Args:
            current_interation (int, optional): provide the current iteration of the call 
            indentValue        (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the method was able to populate the list of Tags otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("load Applications",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable searching for Applications list", tabs = indent_value)
            query_string =  _API_CALLS.GET_APPLICATIONS[:-1] + str(current_interation) 
            self.__setAPICaller(API_METHOD.GET,query_string)
            self.__API_caller.addHeaderParameter("Content-Type","application/json")

            self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
            if self.__API_caller.execute():
                list_of_applications, number_of_interations = self.__getAPIData()
                # self.logThis("list_of_applications", list_of_applications, tabs = indent_value + 1)
                # Initialize the internal application list property
                if current_interation == 1:
                    self.__applications_list = {}
                #  Populate the application list
                if len(list_of_applications) > 0:
                    for current_application in list_of_applications:
                        self.logThis("Selecting", current_application["name"] , tabs = indent_value + 1)
                        self.__applications_list[current_application["name"]] = current_application["id"]
                        result = True
                else:
                    self.logThis("Received an empty list", tabs = indent_value + 1)
                #  Check if we need to perform other iterations
                self.logThis("Iteration " + str(current_interation) + "/" + str(number_of_interations), tabs = indent_value + 1)
                if current_interation < number_of_interations:
                    self.loadApplicationList(current_interation + 1, indent_value + 1)
            else:
                self.logThis("Can't get the list of Applications",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def __checkIfConnectorZoneExists(self, connector_zone : str, indent_value = 1):
        """
          Check if a Connector Zone already exists on the Tenant
           
        Args:
            connector_zone (str): name of the connector zone to check for existence.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return Connector Zone ID if the Connector Zone exists otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("check if connector zone exists",indent_value)
        indent_value += 1

        if connector_zone in self.__connector_zones_list:
            self.logThis("Connector zone exists", tabs = indent_value)
            result = self.__connector_zones_list[connector_zone]
        else:
            self.logThis("Connector zone doesn't exists", tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result
    def __checkIfConnectorExists(self, connector : str, indent_value = 1):
        """
          Check if a Connector already exists on the Tenant
           
        Args:
            connector (str): name of the connector to check for existence.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the Connecter exists otherwise it returns false.
        """
        result = False
   
        self.beginMethodSeparator("check Connector exists",indent_value)
        indent_value += 1

        if connector in self.__connectors_list:
            self.logThis("Connector exists", tabs = indent_value)
            result = True
        else:
            self.logThis("Connector doesn't exists", tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def __checkIfTagExists(self, tag_name : str, indent_value = 1):
        """
          Check if a Tag already exists on the Tenant
           
        Args:
            tag_name.             (str): name of the connector to check for existence.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return True if the tag exists otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("check tag exists",indent_value)
        indent_value += 1

        if tag_name in self.__tags_list:
            result = self.__tags_list[tag_name]
            self.logThis("Tag exists with id ", result, tabs = indent_value)
        else:
            self.logThis("Tag doesn't exists", tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def getConnectorZoneList(self):
        """
          Read the Connector Zone List 
           
        Returns:
            Return the Connector Zone list if it exists otherwise it returns false.
        """
        result = False

        if self.isReachable():
            result = {}
            for current_zone in self.__connector_zones_list:
                result[current_zone] = True
        return result

    def getTagsList(self):
        """
          Read the Tags List 
           
        Returns:
            Return the Tags list if it exists otherwise it returns false.
        """
        result = False

        if self.isReachable():
            result = {}
            for current_tag in self.__tags_list:
                result[current_tag] = True
        return result

    def getApplicationsList(self):
        """
          Read the Applications List 
           
        Returns:
            Return the Applications list if it exists otherwise it returns false.
        """
        result = False

        if self.isReachable():
            result = {}
            self.logThis("list", self.__applications_list)
            for current_application in self.__applications_list:
                result[current_application] = True
        return result

    def getApplicationID(self,application_name, indent_value = 1):
        """
          Get the application ID
           
        Args:
            application_name      (str): name of the application.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the ID of the application if the application exists otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("check if connector zone exists",indent_value)
        indent_value += 1
        self.logThis("Looking for Application ", application_name, tabs = indent_value)
    
        if application_name in self.__applications_list:
            self.logThis("Found", tabs = indent_value)
            result = self.__applications_list[application_name]
        else:
            self.logThis("Not found", tabs = indent_value)

        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def deleteApplication(self,application_name, indent_value = 1):
        """
          Delete an application
           
        Args:
            application_name      (str): name of the application to delete.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the ID of the application if the application exists otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Delete application",indent_value)
        indent_value += 1
    
        if self.isReachable():
            application_id = self.getApplicationID(application_name,indent_value + 1)
            if application_id:
                self.logThis("Application Found. ID is ",application_id,  tabs = indent_value)
                query_string =  _API_CALLS.DELETE_APPLICATIONS + str(application_id) 
                self.__setAPICaller(API_METHOD.DELETE,query_string)
                self.__API_caller.addHeaderParameter("Content-Type","application/json")

                self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
                if self.__API_caller.execute():
                    execution_code = self.__API_caller.getHTTPResponseCode()
                    self.logThis("Application deleted. Execution code ", execution_code, tabs = indent_value + 1)
                else:
                    self.logThis("Can't deleted applications",tabs = indent_value + 1)

            else:
                self.logThis("Not found", tabs = indent_value)

        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)



        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def dumpApplication(self,application_name, indent_value = 1):
        """
          Dump an application
           
        Args:
            application_name      (str): name of the application to dump.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the ID of the application if the application exists otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Delete application",indent_value)
        indent_value += 1
    
        if self.isReachable():
            application_id = self.getApplicationID(application_name,indent_value + 1)
            if application_id:
                self.logThis("Application Found. ID is ",application_id,  tabs = indent_value)
                query_string =  _API_CALLS.DUMP_APPLICATION + str(application_id) 
                self.__setAPICaller(API_METHOD.GET,query_string)
                self.__API_caller.addHeaderParameter("Content-Type","application/json")

                self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
                if self.__API_caller.execute():
                    application_details = self.__getAPIData()
                    result = application_details[0]
                    self.logThis("Application details  ", result, tabs = indent_value + 1)
                else:
                    self.logThis("Can't deleted applications",tabs = indent_value + 1)

            else:
                self.logThis("Not found", tabs = indent_value)

        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)



        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def createNewConnector(self, connector_name, connector_zone,indent_value = 1):
        """
          creates a new connector.
           
        Args:
            connector_name (str): the name of the connnector to create
            connector_zone (str): the connector zone name where the connector will be deployed
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the connector installation script if the method was able to create the connector otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Create New Connector",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            self.__setAPICaller(API_METHOD.POST,_API_CALLS.CREATE_CONNECTOR)
            if self.__checkIfConnectorZoneExists(connector_zone, indent_value + 1):
                connector_zone_id = self.__connector_zones_list[connector_zone]
                data = {"name":connector_name, "connectorZoneID":connector_zone_id,}
                data = {"name":connector_name}
                data = {"name":connector_name,"enabled": True, "connectorZoneId":connector_zone_id,}
                data = {"name":connector_name, "connectorZoneId":connector_zone_id,}
                # data = {"name":connector_name, "connectorZoneID":connector_zone}
                self.__API_caller.setAPIBodyContent(data)
                self.__API_caller.addHeaderParameter("Content-Type","application/json")
                self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
                if self.__API_caller.execute():
                    connector_installation_script = self.__getAPIData()
                    if "command" in connector_installation_script:
                        result = connector_installation_script["command"]
                        self.logThis("Connector installation script is ", connector_installation_script, tabs = indent_value + 1)
                    else:
                        self.logThis("Connector installation not found ", tabs = indent_value + 1)
                        result = False
                else:
                    self.logThis("Can't create the connector",tabs = indent_value + 1)
            else:
                self.logThis("Connector Zone doesn't exists",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def createNewTag(self, tag_name : str, tag_description : str = None,indent_value = 1):
        """
          creates a new connector.
           
        Args:
            tag_name              (str): Name of the tag to create
            tag_description       (str): DEscription for the Tag (optional)
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the tag ID if the method was able to create the connector otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Create New Tag",indent_value)
        indent_value += 1
        if self.isReachable():
            result = self.__checkIfTagExists(tag_name, indent_value + 1)
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            if not result :
                self.__setAPICaller(API_METHOD.POST,_API_CALLS.CREATE_TAG)
                data = {"name":tag_name, "description":tag_description,}
                self.__API_caller.setAPIBodyContent(data)
                self.__API_caller.addHeaderParameter("Content-Type","application/json")
                self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
                if self.__API_caller.execute():
                    call_result, number_of_pages = self.__getAPIData()
                    if "id" in call_result:
                        result = call_result["id"]
                        self.logThis("Tag created ", result, tabs = indent_value + 1)
                    else:
                        self.logThis("Tag creation failed. API call returned : ", call_result, tabs = indent_value + 1)
                        result = False
                else:
                    self.logThis("Tag creation failed.",tabs = indent_value + 1)
            else:
                self.logThis("Tag exists",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def __createNewApplication(self, application_details:dict, connector_zone_id:str, tags:list ,indent_value = 1):
        """
          creates a new application.
           
        Args:
            application_details  (dict): dictionary containing the applicatin details
            connector_zone_id     (str): the connector zone id to which the application should be associated to.
            tags                 (list): List of tags ID associated to the application.
            indentValue (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return true if the applicatin was created successfully. 
        """
        result = False

        self.beginMethodSeparator("Create New Application",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            self.__setAPICaller(API_METHOD.POST,_API_CALLS.CREATE_APPLICATION)
            application_details["connectorZoneID"] = connector_zone_id
            application_details["tags"]            = tags
            application_details["enabled"]         = True
            self.__API_caller.setAPIBodyContent(application_details)
            self.__API_caller.addHeaderParameter("Content-Type","application/json")
            self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
            result = self.__API_caller.execute()
            if result:
                application_created, ignore = self.__getAPIData()
                if "id" in application_created:
                    result = application_created["id"]
                    self.logThis("Application created is ", result, tabs = indent_value + 1)
                else:
                    self.logThis("Application not created ", tabs = indent_value + 1)
                    result = False
            else:
                self.logThis("Can't create the application",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def createNewConnectorZone(self, connector_zone_name, connector_zone_description, indent_value = 1):
        """
          creates a new connector zone.
           
        Args:
            connector_zone_name        (str): the connector zone name to create 
            connector_zone_description (str): the connector zone description 
            indentValue      (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return the connector zone ID if the method was able to create the connector zone otherwise it returns false.
        """
        result = False

        self.beginMethodSeparator("Create New Connector Zone",indent_value)
        indent_value += 1
        if self.isReachable():
            result = self.__checkIfConnectorZoneExists(connector_zone_name, indent_value + 1)
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            if not result :
                self.__setAPICaller(API_METHOD.POST,_API_CALLS.CREATE_CONNECTOR_ZONES)
                data = {"name":connector_zone_name, "description":connector_zone_description,}
                self.__API_caller.setAPIBodyContent(data)
                self.__API_caller.addHeaderParameter("Content-Type","application/json")
                self.__API_caller.prepareHTTPSConnection(self.__fqdn,self.__api_tcp_port)
                if self.__API_caller.execute():
                    call_result, number_of_pages = self.__getAPIData()
                    if "id" in call_result:
                        result = call_result["id"]
                        self.__connector_zones_list[connector_zone_name] = call_result["id"]
                        self.logThis("Connector zone created ", call_result, tabs = indent_value + 1)
                    else:
                        self.logThis("Connector zone creation failed. API call returned : ", call_result, tabs = indent_value + 1)
                        result = False
                else:
                    self.logThis("Connector zone creation failed.",tabs = indent_value + 1)
            else:
                self.logThis("Connector Zone exists",tabs = indent_value + 1)
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result

    def createNewNetworkRangeApplication(self, name: str,connector_zone: str,ip_ranges_or_cidrs: list = IGNORE_THIS,tags: list = IGNORE_THIS,dns_searches: list = IGNORE_THIS,excluded_dns_searches: list = IGNORE_THIS,ports_and_protocols: list = IGNORE_THIS,server_initiated_ports: list = IGNORE_THIS,enabled: bool = IGNORE_THIS,enable_icmp: bool = True,enforce_resolved_dns_to_ip: bool = False, connector_zone_description : str = None, indent_value = 1):
        """
          creates a new Network range application.
           
        Args:
        name                        (str): The application name (required).
        connector_zone              (str): The connector zone ID (required).
        ip_ranges_or_cidrs         (list): List of IPs/ranges/CIDRs (at least one of this or dns_searches is required).
        dns_searches               (list): List of FQDNs or wildcards (at least one of this or ip_ranges_or_cidrs is required).
        excluded_dns_searches      (list): List of excluded FQDNs/wildcards (optional).
        ports_and_protocols        (list): List of port ranges and protocols (required).
        server_initiated_ports     (list): List of ports the agent listens on (optional).
        tags                       (list): List of tag dicts with "ID" field (optional).
        enabled                    (bool): Set False to disable the application. Default: True.
        enable_icmp                (bool): Set True to allow ICMP traffic. Default: True.
        enforce_resolved_dns_to_ip (bool): Tunnel only DNS resolving to included IPs. Default: False.
        connector_zone_description  (str): The connector zone description for new connector zone (optional).
        indentValue       (int, optional): Indentation level for debugging purposes. Defaults to 1.

        Returns:
            Return true if the application was created successfully. 
        """
        result = False


        self.beginMethodSeparator("Create New Network Range Application",indent_value)
        indent_value += 1
        if self.isReachable():
            self.logThis("API Gateway Server is reachable", tabs = indent_value)
            # First step is to check if the connector Zone exists and if not create it then retreive the connector zone ID
            connector_zone_id = self.__checkIfConnectorZoneExists(connector_zone, indent_value + 1)
            if not connector_zone_id:
                if not connector_zone_description:
                    connector_zone_description = connector_zone + _DEFAULT_CONNECTOR_ZONE_DESCRIPTION + (datetime.now()).strftime("%c")
                connector_zone_id = self.createNewConnectorZone(connector_zone,connector_zone_description,indent_value + 1)

            if connector_zone_id:
                # Second step is to check if the tags in the list of tags exists and if not create them and then retreive the tag IDs
                list_of_tags_id = []
                for current_tag in tags:
                    tag_name = current_tag
                    if "name" in tag_name:
                        tag_name = current_tag["name"]
                    self.logThis("Looking for ", tag_name,indent_value)
                    current_tag_id = self.__checkIfTagExists(tag_name,indent_value + 1)
                    if not current_tag_id:
                        if "name" in current_tag:
                            tag_description = current_tag["description"]
                        else:
                            tag_description = tag_name + _DEFAULT_TAG_DESCRIPTION + (datetime.now()).strftime("%c") 
                        current_tag_id = self.createNewTag(tag_name,tag_description,indent_value + 1)
                    if current_tag_id:
                        current_tag_id = {"ID" : current_tag_id}
                        list_of_tags_id.append(current_tag_id)
                    else:
                        self.logThis("Skipping tag " + tag_name)

                # Third step is to create the application details dictionary 
                application_details                                                          = {}
                application_details["NetworkRangeApplicationData"]                           = {}
                # if ip_ranges_or_cidrs         is not None: application_details["NetworkRangeApplicationData"]["IpRangesOrCIDRs"]        = ip_ranges_or_cidrs
                # if dns_searches               is not None: application_details["NetworkRangeApplicationData"]["DnsSearches"]            = dns_searches
                # if excluded_dns_searches      is not None: application_details["NetworkRangeApplicationData"]["ExcludedDnsSearches"]    = excluded_dns_searches
                # if enable_icmp                is not None: application_details["NetworkRangeApplicationData"]["EnableICMP"]             = enable_icmp
                # if ports_and_protocols        is not None: application_details["NetworkRangeApplicationData"]["PortsAndProtocols"]      = ports_and_protocols
                # if server_initiated_ports     is not None: application_details["NetworkRangeApplicationData"]["ServerInitiatedPorts"]   = server_initiated_ports
                # if enforce_resolved_dns_to_ip is not None: application_details["NetworkRangeApplicationData"]["EnforceResolvedDnsToIP"] = enforce_resolved_dns_to_ip

                if ip_ranges_or_cidrs         is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["IpRangesOrCIDRs"]        = ip_ranges_or_cidrs
                if dns_searches               is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["DnsSearches"]            = dns_searches
                if excluded_dns_searches      is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["ExcludedDnsSearches"]    = excluded_dns_searches
                if enable_icmp                is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["EnableICMP"]             = enable_icmp
                if ports_and_protocols        is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["PortsAndProtocols"]      = ports_and_protocols
                if server_initiated_ports     is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["ServerInitiatedPorts"]   = server_initiated_ports
                if enforce_resolved_dns_to_ip is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["EnforceResolvedDnsToIP"] = enforce_resolved_dns_to_ip
                if enabled                    is not IGNORE_THIS: application_details["NetworkRangeApplicationData"]["enabled"]                = DEFAULT_APPPLICATION_ENABLE_STATUS

                if ports_and_protocols        is     IGNORE_THIS: application_details["NetworkRangeApplicationData"]["PortsAndProtocols"]      = _DEFAULT_PORTS_AND_PROTOCOLS



                application_details["name"]                                                  = name
                application_details["type"]                                                  = HPE_SSE_APPLICATION_TYPES.NETWORK_RANGE

                application_id = self.__createNewApplication(application_details,connector_zone_id,list_of_tags_id,indent_value + 1)
                if application_id:
                    self.logThis("Application Created successfully",application_id, indent_value)
                    result = application_id
                else:
                    self.logThis("Application Creation failed ",application_id, indent_value)
            else: 
                self.logThis("Can't create the application as the connector zone can't be created")             
        else:                 
            self.logThis("API gateway not reachable", tabs = indent_value + 2)
            
        indent_value -= 1
        self.endMethodSeparator(indent_value)
        return result


